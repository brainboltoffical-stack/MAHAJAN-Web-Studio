"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  CheckCheck,
  ChevronLeft,
  ChevronRight,
  Eye,
  EyeOff,
  Inbox,
  Loader2,
  Mail,
  MailOpen,
  RotateCcw,
  Search,
  Trash2,
  Briefcase,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { PageHeader, Panel, LoadingBlock, ErrorBlock, EmptyState, STATUS_LIST, STATUS_STYLES, formatIstDateTime } from "@/components/admin/ui-bits";
import { adminFetch } from "@/lib/admin/client";
import { cn } from "@/lib/utils";

type Message = {
  id: string;
  name: string;
  businessName: string | null;
  email: string;
  websiteType: string;
  description: string;
  status: string;
  isRead: boolean;
  createdAt: string;
};

type ListResponse = {
  messages: Message[];
  total: number;
  page: number;
  pages: number;
  unreadCount: number;
  statusCounts: Record<string, number>;
};

const EMPTY: ListResponse = {
  messages: [],
  total: 0,
  page: 1,
  pages: 1,
  unreadCount: 0,
  statusCounts: {},
};

export default function AdminMessagesPage() {
  const [data, setData] = useState<ListResponse>(EMPTY);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [readFilter, setReadFilter] = useState("all");
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<Message | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Message | null>(null);
  const [deleting, setDeleting] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const load = useCallback(() => {
    setLoading(true);
    setError(null);
    const params = new URLSearchParams({ page: String(page), status: statusFilter, read: readFilter });
    if (query.trim()) params.set("q", query.trim());
    adminFetch<ListResponse>(`/api/admin/messages?${params.toString()}`)
      .then((d) => {
        setData(d);
        // Keep the open detail panel in sync after actions.
        setSelected((prev) => (prev ? d.messages.find((m) => m.id === prev.id) ?? prev : prev));
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [page, statusFilter, readFilter, query]);

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(load, query ? 350 : 0);
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [load, query]);

  const patchMessage = async (id: string, body: { isRead?: boolean; status?: string }) => {
    setBusyId(id);
    try {
      const res = await adminFetch<{ message: Message }>(`/api/admin/messages/${id}`, {
        method: "PATCH",
        body: JSON.stringify(body),
      });
      setData((d) => ({
        ...d,
        messages: d.messages.map((m) => (m.id === id ? res.message : m)),
        unreadCount: body.isRead === undefined ? d.unreadCount : body.isRead ? Math.max(0, d.unreadCount - (d.messages.find((m) => m.id === id && !m.isRead) ? 1 : 0)) : d.unreadCount + (d.messages.find((m) => m.id === id && m.isRead) ? 1 : 0),
      }));
      setSelected((prev) => (prev && prev.id === id ? res.message : prev));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Action failed");
    } finally {
      setBusyId(null);
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await adminFetch(`/api/admin/messages/${deleteTarget.id}`, { method: "DELETE" });
      setData((d) => ({
        ...d,
        messages: d.messages.filter((m) => m.id !== deleteTarget.id),
        total: d.total - 1,
      }));
      setSelected((prev) => (prev && prev.id === deleteTarget.id ? null : prev));
      setDeleteTarget(null);
      load();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Delete failed");
    } finally {
      setDeleting(false);
    }
  };

  const openMessage = (m: Message) => {
    setSelected(m);
    if (!m.isRead) patchMessage(m.id, { isRead: true });
  };

  const filtersActive = useMemo(
    () => query.trim() !== "" || statusFilter !== "all" || readFilter !== "all",
    [query, statusFilter, readFilter]
  );

  return (
    <>
      <PageHeader
        title="Messages / Inbox"
        subtitle="Every contact form submission, stored securely and visible only to you."
      />

      {/* Filters */}
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
        <div className="relative flex-1 sm:min-w-[220px]">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
          <Input
            value={query}
            onChange={(e) => {
              setPage(1);
              setQuery(e.target.value);
            }}
            placeholder="Search by name, email or business…"
            className="h-10 border-white/10 bg-white/[0.04] pl-10 text-white placeholder:text-muted-foreground/50 focus-visible:border-electric-500/60"
            aria-label="Search messages"
          />
        </div>
        <Select
          value={statusFilter}
          onValueChange={(v) => {
            setPage(1);
            setStatusFilter(v);
          }}
        >
          <SelectTrigger className="!h-10 w-full border-white/10 bg-white/[0.04] text-white data-[placeholder]:text-muted-foreground sm:w-[190px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent className="border-white/10 bg-[#0d1019] text-white">
            <SelectItem value="all">All statuses</SelectItem>
            {STATUS_LIST.map((s) => (
              <SelectItem key={s} value={s}>
                {s} ({data.statusCounts[s] ?? 0})
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select
          value={readFilter}
          onValueChange={(v) => {
            setPage(1);
            setReadFilter(v);
          }}
        >
          <SelectTrigger className="!h-10 w-full border-white/10 bg-white/[0.04] text-white data-[placeholder]:text-muted-foreground sm:w-[150px]">
            <SelectValue placeholder="Read state" />
          </SelectTrigger>
          <SelectContent className="border-white/10 bg-[#0d1019] text-white">
            <SelectItem value="all">All messages</SelectItem>
            <SelectItem value="unread">Unread only</SelectItem>
            <SelectItem value="read">Read only</SelectItem>
          </SelectContent>
        </Select>
        {filtersActive && (
          <Button
            variant="outline"
            className="h-10 rounded-xl border-white/10 bg-white/[0.03] text-foreground hover:bg-white/[0.07] hover:text-white"
            onClick={() => {
              setQuery("");
              setStatusFilter("all");
              setReadFilter("all");
              setPage(1);
            }}
          >
            <RotateCcw className="mr-1.5 h-3.5 w-3.5" aria-hidden />
            Reset
          </Button>
        )}
      </div>

      {error && (
        <div className="mb-5">
          <ErrorBlock message={error} onRetry={load} />
        </div>
      )}

      <div className="grid gap-5 xl:grid-cols-[1fr_420px]">
        {/* List */}
        <Panel className="min-h-[420px]">
          {loading ? (
            <LoadingBlock />
          ) : data.messages.length === 0 ? (
            <EmptyState
              icon={Inbox}
              title={filtersActive ? "No matching messages" : "No enquiries yet"}
              message={
                filtersActive
                  ? "Try different search terms or reset the filters."
                  : "When a visitor submits the contact form on your website, the message appears here instantly."
              }
            />
          ) : (
            <>
              <ul className="divide-y divide-white/[0.06]">
                {data.messages.map((m) => (
                  <li key={m.id}>
                    <button
                      onClick={() => openMessage(m)}
                      className={cn(
                        "flex w-full items-start gap-3.5 rounded-lg px-2.5 py-4 text-left transition-colors hover:bg-white/[0.03] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                        selected?.id === m.id && "bg-electric-500/[0.08]"
                      )}
                    >
                      <span className={cn("mt-1.5 h-2 w-2 shrink-0 rounded-full", m.isRead ? "bg-white/20" : "bg-electric-400")} aria-hidden />
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1">
                          <p className={cn("truncate text-sm", m.isRead ? "font-medium text-foreground/80" : "font-semibold text-white")}>
                            {m.name}
                          </p>
                          {m.businessName && (
                            <span className="inline-flex items-center gap-1 text-[11px] text-muted-foreground">
                              <Briefcase className="h-3 w-3" aria-hidden />
                              {m.businessName}
                            </span>
                          )}
                          <span className={cn("rounded-full border px-2 py-0.5 text-[10px] font-semibold", STATUS_STYLES[m.status] ?? "")}>
                            {m.status}
                          </span>
                        </div>
                        <p className="mt-1 truncate text-[12.5px] text-muted-foreground">{m.email}</p>
                        <p className="mt-1 line-clamp-1 text-[12.5px] text-foreground/60">{m.description}</p>
                        <p className="mt-1.5 text-[11px] text-muted-foreground/70">{formatIstDateTime(m.createdAt)} (IST)</p>
                      </div>
                      {m.isRead ? (
                        <MailOpen className="mt-1 h-4 w-4 shrink-0 text-muted-foreground/50" aria-label="Read" />
                      ) : (
                        <Mail className="mt-1 h-4 w-4 shrink-0 text-electric-400" aria-label="Unread" />
                      )}
                    </button>
                  </li>
                ))}
              </ul>

              {/* Pagination */}
              {data.pages > 1 && (
                <div className="mt-4 flex items-center justify-between border-t border-white/[0.06] pt-4">
                  <p className="text-[12px] text-muted-foreground">
                    Page {data.page} of {data.pages} · {data.total} message{data.total === 1 ? "" : "s"}
                  </p>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8 rounded-lg border-white/10 bg-white/[0.03] text-white hover:bg-white/[0.08]"
                      disabled={data.page <= 1}
                      onClick={() => setPage((p) => Math.max(1, p - 1))}
                      aria-label="Previous page"
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8 rounded-lg border-white/10 bg-white/[0.03] text-white hover:bg-white/[0.08]"
                      disabled={data.page >= data.pages}
                      onClick={() => setPage((p) => Math.min(data.pages, p + 1))}
                      aria-label="Next page"
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </Panel>

        {/* Detail panel */}
        <div className="xl:sticky xl:top-8 xl:self-start">
          <Panel title="Message details" className="min-h-[420px]">
            {selected ? (
              <div className="space-y-5">
                <div>
                  <div className="flex items-start justify-between gap-3">
                    <h3 className="font-display text-lg font-bold leading-snug text-white">{selected.name}</h3>
                    <span className={cn("shrink-0 rounded-full border px-2.5 py-1 text-[10.5px] font-semibold", STATUS_STYLES[selected.status] ?? "")}>
                      {selected.status}
                    </span>
                  </div>
                  <p className="mt-1 text-[12px] text-muted-foreground">
                    Received {formatIstDateTime(selected.createdAt)} (IST)
                  </p>
                </div>

                <dl className="space-y-3 rounded-xl border border-white/[0.06] bg-white/[0.02] p-4 text-sm">
                  <div>
                    <dt className="text-[10.5px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">Email</dt>
                    <dd className="mt-0.5 break-all">
                      <a href={`mailto:${selected.email}`} className="text-electric-300 underline-offset-4 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded">
                        {selected.email}
                      </a>
                    </dd>
                  </div>
                  <div>
                    <dt className="text-[10.5px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">Business</dt>
                    <dd className="mt-0.5 text-foreground/85">{selected.businessName || "—"}</dd>
                  </div>
                  <div>
                    <dt className="text-[10.5px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">Type of website</dt>
                    <dd className="mt-0.5 text-foreground/85">{selected.websiteType}</dd>
                  </div>
                </dl>

                <div>
                  <p className="mb-1.5 text-[10.5px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                    Project description
                  </p>
                  <p className="whitespace-pre-wrap rounded-xl border border-white/[0.06] bg-white/[0.02] p-4 text-[13.5px] leading-relaxed text-foreground/90">
                    {selected.description}
                  </p>
                </div>

                <div className="space-y-2.5 border-t border-white/[0.06] pt-4">
                  <p className="text-[10.5px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">Actions</p>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      disabled={busyId === selected.id}
                      onClick={() => patchMessage(selected.id, { isRead: !selected.isRead })}
                      className="rounded-lg border-white/10 bg-white/[0.03] text-[12.5px] text-foreground hover:bg-white/[0.08] hover:text-white"
                    >
                      {busyId === selected.id ? (
                        <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" aria-hidden />
                      ) : selected.isRead ? (
                        <EyeOff className="mr-1.5 h-3.5 w-3.5" aria-hidden />
                      ) : (
                        <Eye className="mr-1.5 h-3.5 w-3.5" aria-hidden />
                      )}
                      Mark as {selected.isRead ? "Unread" : "Read"}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      disabled={busyId === selected.id}
                      onClick={() => patchMessage(selected.id, { status: "Completed", isRead: true })}
                      className="rounded-lg border-white/10 bg-white/[0.03] text-[12.5px] text-foreground hover:bg-white/[0.08] hover:text-white"
                    >
                      <CheckCheck className="mr-1.5 h-3.5 w-3.5" aria-hidden />
                      Complete
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setDeleteTarget(selected)}
                      className="rounded-lg border-white/10 bg-white/[0.03] text-[12.5px] text-foreground hover:border-red-500/40 hover:bg-red-500/10 hover:text-red-300"
                    >
                      <Trash2 className="mr-1.5 h-3.5 w-3.5" aria-hidden />
                      Delete
                    </Button>
                  </div>
                  <div>
                    <p className="mb-1.5 mt-3 text-[10.5px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                      Enquiry status
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {STATUS_LIST.map((status) => (
                        <button
                          key={status}
                          disabled={busyId === selected.id || selected.status === status}
                          onClick={() => patchMessage(selected.id, { status })}
                          className={cn(
                            "rounded-full border px-3 py-1.5 text-[11.5px] font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-default",
                            selected.status === status
                              ? STATUS_STYLES[status]
                              : "border-white/10 bg-white/[0.03] text-muted-foreground hover:border-electric-500/40 hover:text-electric-300"
                          )}
                        >
                          {status}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <EmptyState
                icon={MailOpen}
                title="Select a message"
                message="Choose a message from the inbox to read the full enquiry and manage its status."
              />
            )}
          </Panel>
        </div>
      </div>

      {/* Delete confirmation */}
      <Dialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <DialogContent className="border-white/10 bg-[#0d1019] text-white sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-display">Delete this message?</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              This permanently removes the enquiry from {deleteTarget?.name} ({deleteTarget?.email}). This
              action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={() => setDeleteTarget(null)}
              className="rounded-full border-white/15 bg-transparent text-foreground hover:bg-white/[0.06] hover:text-white"
            >
              Cancel
            </Button>
            <Button
              onClick={confirmDelete}
              disabled={deleting}
              className="rounded-full bg-red-500/90 font-semibold text-white hover:bg-red-500"
            >
              {deleting ? (
                <>
                  <Loader2 className="mr-1.5 h-4 w-4 animate-spin" aria-hidden />
                  Deleting…
                </>
              ) : (
                "Delete permanently"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
