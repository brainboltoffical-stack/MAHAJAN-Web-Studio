"use client";

import { useCallback, useEffect, useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  DatabaseBackup,
  Eye,
  EyeOff,
  HardDrive,
  KeyRound,
  Loader2,
  LogOut,
  Mail,
  RefreshCcw,
  ShieldCheck,
  Unlock,
  XCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { PageHeader, Panel, LoadingBlock, formatIstDateTime } from "@/components/admin/ui-bits";
import { adminFetch } from "@/lib/admin/client";
import { cn } from "@/lib/utils";

type SessionRow = {
  id: string;
  userAgent: string | null;
  createdAt: string;
  expiresAt: string;
  ipHash: string | null;
  current: boolean;
};

type Logs = {
  activity: { id: string; action: string; detail: string | null; createdAt: string }[];
  attempts: { id: string; username: string; success: boolean; createdAt: string }[];
};

export default function AdminSettingsPage() {
  const [sessions, setSessions] = useState<SessionRow[] | null>(null);
  const [logs, setLogs] = useState<Logs | null>(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<{ kind: "ok" | "err"; text: string } | null>(null);

  // password form
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPw, setShowPw] = useState(false);

  // revoke-all confirmation
  const [confirmRevoke, setConfirmRevoke] = useState(false);

  const load = useCallback(() => {
    adminFetch<{ sessions: SessionRow[] }>("/api/admin/sessions")
      .then((d) => setSessions(d.sessions))
      .catch(() => setSessions([]));
    adminFetch<Logs>("/api/admin/logs")
      .then(setLogs)
      .catch(() => setLogs({ activity: [], attempts: [] }));
  }, []);

  useEffect(load, [load]);

  const changePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setNotice(null);
    if (newPassword.length < 10) {
      setNotice({ kind: "err", text: "New password must be at least 10 characters long." });
      return;
    }
    if (newPassword !== confirmPassword) {
      setNotice({ kind: "err", text: "New password and confirmation do not match." });
      return;
    }
    setBusy(true);
    try {
      const res = await adminFetch<{ revokedOthers: number }>("/api/admin/password", {
        method: "POST",
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      setNotice({
        kind: "ok",
        text: `Password changed securely. ${res.revokedOthers} other session(s) signed out.`,
      });
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      load();
    } catch (err) {
      setNotice({ kind: "err", text: err instanceof Error ? err.message : "Password change failed." });
    } finally {
      setBusy(false);
    }
  };

  const revokeOne = async (id: string) => {
    setBusy(true);
    try {
      await adminFetch(`/api/admin/sessions?id=${id}`, { method: "DELETE" });
      if (sessions?.find((s) => s.id === id)?.current) {
        window.location.href = "/admin/login";
        return;
      }
      load();
    } catch (err) {
      setNotice({ kind: "err", text: err instanceof Error ? err.message : "Revoke failed." });
    } finally {
      setBusy(false);
    }
  };

  const revokeOthers = async () => {
    setBusy(true);
    setConfirmRevoke(false);
    try {
      const res = await adminFetch<{ revoked: number }>("/api/admin/sessions?scope=others", { method: "DELETE" });
      setNotice({ kind: "ok", text: `${res.revoked} other session(s) revoked.` });
      load();
    } catch (err) {
      setNotice({ kind: "err", text: err instanceof Error ? err.message : "Revoke failed." });
    } finally {
      setBusy(false);
    }
  };

  const clearLockouts = async () => {
    setBusy(true);
    try {
      const res = await adminFetch<{ cleared: number }>("/api/admin/unlock", { method: "POST" });
      setNotice({ kind: "ok", text: `${res.cleared} active login lockout(s) cleared.` });
    } catch (err) {
      setNotice({ kind: "err", text: err instanceof Error ? err.message : "Failed." });
    } finally {
      setBusy(false);
    }
  };

  const runBackup = async () => {
    setBusy(true);
    try {
      const res = await adminFetch<{ file: string }>("/api/admin/backup", { method: "POST" });
      setNotice({ kind: "ok", text: `Database backup created: ${res.file}` });
    } catch (err) {
      setNotice({ kind: "err", text: err instanceof Error ? err.message : "Backup failed." });
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <PageHeader title="Settings" subtitle="Security, sessions, monitoring and integrations." />

      {notice && (
        <div
          role="status"
          className={cn(
            "mb-6 flex items-start gap-3 rounded-2xl border px-5 py-4 text-sm",
            notice.kind === "ok"
              ? "border-emerald-500/30 bg-emerald-500/[0.08] text-emerald-200"
              : "border-red-500/30 bg-red-500/[0.08] text-red-300"
          )}
        >
          {notice.kind === "ok" ? (
            <CheckCircle2 className="mt-0.5 h-4.5 w-4.5 h-[18px] w-[18px] shrink-0" aria-hidden />
          ) : (
            <AlertTriangle className="mt-0.5 h-[18px] w-[18px] shrink-0" aria-hidden />
          )}
          <span className="leading-relaxed">{notice.text}</span>
        </div>
      )}

      <div className="grid gap-6 xl:grid-cols-2">
        {/* Password */}
        <Panel title="Change password" subtitle="Hashed with scrypt. All other sessions are signed out after a change.">
          <form onSubmit={changePassword} className="space-y-4" autoComplete="off">
            <div className="space-y-2">
              <Label htmlFor="currentPassword" className="text-sm text-foreground">Current password</Label>
              <Input
                id="currentPassword"
                type={showPw ? "text" : "password"}
                autoComplete="current-password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="h-11 border-white/10 bg-white/[0.04] text-white focus-visible:border-electric-500/60"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="newPassword" className="text-sm text-foreground">New password (min 10 characters)</Label>
              <div className="relative">
                <Input
                  id="newPassword"
                  type={showPw ? "text" : "password"}
                  autoComplete="new-password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="h-11 border-white/10 bg-white/[0.04] pr-11 text-white focus-visible:border-electric-500/60"
                />
                <button
                  type="button"
                  onClick={() => setShowPw((s) => !s)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 rounded p-1 text-muted-foreground hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  aria-label={showPw ? "Hide passwords" : "Show passwords"}
                >
                  {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirmPassword" className="text-sm text-foreground">Confirm new password</Label>
              <Input
                id="confirmPassword"
                type={showPw ? "text" : "password"}
                autoComplete="new-password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="h-11 border-white/10 bg-white/[0.04] text-white focus-visible:border-electric-500/60"
              />
            </div>
            <Button
              type="submit"
              disabled={busy || !currentPassword || !newPassword || !confirmPassword}
              className="glow-electric h-11 w-full rounded-full bg-electric-500 font-semibold text-white hover:bg-electric-600 disabled:opacity-60"
            >
              {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden /> : <KeyRound className="mr-2 h-4 w-4" aria-hidden />}
              Update password securely
            </Button>
          </form>
        </Panel>

        {/* Integrations & infrastructure status */}
        <Panel title="Integration status" subtitle="What is active now, and exactly what needs manual setup.">
          <IntegrationStatus />
        </Panel>

        {/* Sessions */}
        <Panel
          title="Active sessions"
          subtitle="Every signed-in device. Revoke any session instantly."
          action={
            <Button
              size="sm"
              variant="outline"
              onClick={() => setConfirmRevoke(true)}
              disabled={busy || !sessions || sessions.filter((s) => !s.current).length === 0}
              className="rounded-lg border-white/10 bg-white/[0.03] text-[12px] text-foreground hover:border-red-500/40 hover:bg-red-500/10 hover:text-red-300"
            >
              <LogOut className="mr-1.5 h-3.5 w-3.5" aria-hidden />
              Revoke others
            </Button>
          }
        >
          {!sessions ? (
            <LoadingBlock label="Loading sessions…" />
          ) : sessions.length === 0 ? (
            <p className="py-6 text-center text-[12.5px] text-muted-foreground">No active sessions.</p>
          ) : (
            <ul className="space-y-3">
              {sessions.map((s) => (
                <li key={s.id} className="flex items-start justify-between gap-3 rounded-xl border border-white/[0.06] bg-white/[0.02] p-4">
                  <div className="min-w-0">
                    <p className="flex items-center gap-2 text-sm font-medium text-white">
                      {s.current ? "This device" : "Other session"}
                      {s.current && (
                        <span className="rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2 py-0.5 text-[9.5px] font-bold uppercase tracking-wider text-emerald-300">
                          Current
                        </span>
                      )}
                    </p>
                    <p className="mt-1 truncate text-[11.5px] text-muted-foreground" title={s.userAgent ?? ""}>
                      {s.userAgent ? shortenUa(s.userAgent) : "Unknown device"}
                    </p>
                    <p className="mt-0.5 text-[11px] text-muted-foreground/70">
                      Started {formatIstDateTime(s.createdAt)} · Expires {formatIstDateTime(s.expiresAt)}
                    </p>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={busy}
                    onClick={() => revokeOne(s.id)}
                    className="shrink-0 rounded-lg border-white/10 bg-white/[0.03] text-[11.5px] text-foreground hover:border-red-500/40 hover:bg-red-500/10 hover:text-red-300"
                  >
                    Revoke
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </Panel>

        {/* Security actions */}
        <Panel title="Security monitoring" subtitle="Login activity, lockouts and backups.">
          <div className="space-y-4">
            <div className="grid gap-3 sm:grid-cols-2">
              <Button
                onClick={clearLockouts}
                disabled={busy}
                variant="outline"
                className="h-auto justify-start rounded-xl border-white/10 bg-white/[0.03] px-4 py-3.5 text-left hover:border-electric-500/40 hover:text-white"
              >
                <span>
                  <Unlock className="mb-1.5 h-4 w-4 text-electric-400" aria-hidden />
                  <span className="block text-sm font-medium">Clear login lockouts</span>
                  <span className="mt-0.5 block text-[11.5px] font-normal text-muted-foreground">
                    Manually unban blocked login attempts
                  </span>
                </span>
              </Button>
              <Button
                onClick={runBackup}
                disabled={busy}
                variant="outline"
                className="h-auto justify-start rounded-xl border-white/10 bg-white/[0.03] px-4 py-3.5 text-left hover:border-electric-500/40 hover:text-white"
              >
                <span>
                  <DatabaseBackup className="mb-1.5 h-4 w-4 text-electric-400" aria-hidden />
                  <span className="block text-sm font-medium">Create database backup</span>
                  <span className="mt-0.5 block text-[11.5px] font-normal text-muted-foreground">
                    Consistent snapshot via SQLite VACUUM
                  </span>
                </span>
              </Button>
            </div>

            {logs && (
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                    Recent login attempts
                  </p>
                  <ul className="max-h-56 space-y-1.5 overflow-y-auto pr-1 text-[12px]">
                    {logs.attempts.length === 0 && <li className="text-muted-foreground">No attempts recorded.</li>}
                    {logs.attempts.map((a) => (
                      <li key={a.id} className="flex items-center justify-between gap-2 rounded-lg bg-white/[0.02] px-3 py-2">
                        <span className="truncate text-foreground/85">{a.username}</span>
                        <span className="flex shrink-0 items-center gap-1.5">
                          {a.success ? (
                            <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" aria-label="Success" />
                          ) : (
                            <XCircle className="h-3.5 w-3.5 text-red-400" aria-label="Failed" />
                          )}
                          <span className="text-[10.5px] text-muted-foreground">
                            {formatIstDateTime(a.createdAt).split(",")[1] ?? ""}
                          </span>
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                    Admin activity log
                  </p>
                  <ul className="max-h-56 space-y-1.5 overflow-y-auto pr-1 text-[12px]">
                    {logs.activity.length === 0 && <li className="text-muted-foreground">No activity recorded.</li>}
                    {logs.activity.map((a) => (
                      <li key={a.id} className="rounded-lg bg-white/[0.02] px-3 py-2">
                        <span className="font-medium text-electric-300">{a.action}</span>
                        {a.detail && <span className="ml-1.5 text-muted-foreground">{a.detail}</span>}
                        <span className="mt-0.5 block text-[10.5px] text-muted-foreground/70">
                          {formatIstDateTime(a.createdAt)}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
            <p className="flex items-start gap-2 border-t border-white/[0.06] pt-3 text-[11.5px] leading-relaxed text-muted-foreground">
              <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-electric-400" aria-hidden />
              Passwords and tokens are never written to logs — only usernames, outcomes and IP hashes.
            </p>
          </div>
        </Panel>
      </div>

      {/* Revoke others confirmation */}
      <Dialog open={confirmRevoke} onOpenChange={setConfirmRevoke}>
        <DialogContent className="border-white/10 bg-[#0d1019] text-white sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-display">Revoke all other sessions?</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Every signed-in device except this one will be logged out immediately.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={() => setConfirmRevoke(false)}
              className="rounded-full border-white/15 bg-transparent text-foreground hover:bg-white/[0.06] hover:text-white"
            >
              Cancel
            </Button>
            <Button onClick={revokeOthers} disabled={busy} className="rounded-full bg-electric-500 font-semibold text-white hover:bg-electric-600">
              {busy ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" aria-hidden /> : null}
              Revoke sessions
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

function shortenUa(ua: string): string {
  if (/Edg\//.test(ua)) return "Edge";
  if (/OPR\//.test(ua)) return "Opera";
  if (/Chrome\//.test(ua)) return "Chrome";
  if (/Firefox\//.test(ua)) return "Firefox";
  if (/Safari\//.test(ua)) return "Safari";
  return ua.slice(0, 60);
}

function IntegrationStatus() {
  const [status, setStatus] = useState<{
    mail: { provider: string; lastEnquiry: { status: string; createdAt: string } | null; lastAlert: { status: string; createdAt: string } | null };
    https: { protocol: string | null };
    backups: { last: string | null; count: number };
  } | null>(null);

  useEffect(() => {
    adminFetch<typeof status>("/api/admin/status").then((s) => setStatus(s)).catch(() => undefined);
  }, []);

  if (!status) {
    return (
      <div className="space-y-3">
        {[0, 1, 2].map((i) => (
          <div key={i} className="h-16 animate-pulse rounded-xl bg-white/[0.04]" />
        ))}
      </div>
    );
  }

  const items = [
    {
      icon: Mail,
      title: "Email notifications",
      ok: status.mail.provider !== null,
      detail: status.mail.provider
        ? `${status.mail.provider} connected. Enquiries are emailed to the studio address.`
        : "Not configured. Set the SMTP_URL or RESEND_API_KEY environment variable on the server, then enquiries and security alerts are emailed to brainboltoffical@gmail.com automatically." +
          (status.mail.lastEnquiry ? ` Latest enquiry notification: ${status.mail.lastEnquiry.status}.` : ""),
    },
    {
      icon: ShieldCheck,
      title: "HTTPS / transport security",
      ok: status.https.protocol === "https",
      detail:
        status.https.protocol === "https"
          ? "Detected HTTPS via the hosting gateway. HSTS and secure headers are active."
          : "Currently served over HTTP in the local sandbox. The production host must enable HTTPS (automatic on Vercel/Netlify/Cloudflare) — all security headers are already configured.",
    },
    {
      icon: HardDrive,
      title: "Database backups",
      ok: status.backups.count > 0,
      detail:
        status.backups.count > 0
          ? `${status.backups.count} backup(s) on the server. Latest: ${status.backups.last}. You can also run "bun run db:backup" on the host.`
          : "No backups yet. Create one from the Security monitoring card, or run \"bun run db:backup\" on the host. Store copies outside the server for full safety.",
    },
  ];

  return (
    <ul className="space-y-3">
      {items.map((item) => (
        <li key={item.title} className="flex items-start gap-3.5 rounded-xl border border-white/[0.06] bg-white/[0.02] p-4">
          <span
            className={cn(
              "flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border",
              item.ok ? "border-emerald-500/30 bg-emerald-500/10" : "border-amber-500/30 bg-amber-500/10"
            )}
          >
            <item.icon className={cn("h-4 w-4", item.ok ? "text-emerald-400" : "text-amber-400")} aria-hidden />
          </span>
          <div className="min-w-0">
            <p className="flex flex-wrap items-center gap-2 text-sm font-semibold text-white">
              {item.title}
              <span
                className={cn(
                  "rounded-full border px-2 py-0.5 text-[9.5px] font-bold uppercase tracking-wider",
                  item.ok ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-300" : "border-amber-500/30 bg-amber-500/10 text-amber-300"
                )}
              >
                {item.ok ? "Active" : "Action needed"}
              </span>
            </p>
            <p className="mt-1 text-[12px] leading-relaxed text-muted-foreground">{item.detail}</p>
          </div>
        </li>
      ))}
      <li className="flex items-start gap-3.5 rounded-xl border border-white/[0.06] bg-white/[0.02] p-4">
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-electric-500/30 bg-electric-500/10">
          <RefreshCcw className="h-4 w-4 text-electric-400" aria-hidden />
        </span>
        <div>
          <p className="text-sm font-semibold text-white">Supabase / Firebase migration path</p>
          <p className="mt-1 text-[12px] leading-relaxed text-muted-foreground">
            The current stack uses the same architecture (parameterised queries, server-side authorisation,
            hashed credentials, revocable sessions). To move to Supabase Auth or Firebase Authentication,
            create the project, set its keys as server-only environment variables and point the Prisma
            datasource at the managed database — the admin UI and APIs remain unchanged.
          </p>
        </div>
      </li>
    </ul>
  );
}
