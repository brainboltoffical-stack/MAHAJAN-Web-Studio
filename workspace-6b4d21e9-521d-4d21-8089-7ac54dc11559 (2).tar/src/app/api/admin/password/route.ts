import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import {
  getClientIp,
  hashPassword,
  logActivity,
  passesCsrfChecks,
  requireAdmin,
  revokeAllSessionsForAdmin,
  verifyPassword,
} from "@/lib/admin/auth";

const schema = z.object({
  currentPassword: z.string().min(1).max(200),
  newPassword: z.string().min(10).max(200),
});

export async function POST(request: Request) {
  const ctx = await requireAdmin(request);
  if (!ctx) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!passesCsrfChecks(request)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const body = await request.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "New password must be at least 10 characters." },
      { status: 400 }
    );
  }

  const { currentPassword, newPassword } = parsed.data;
  const admin = await db.adminUser.findUnique({ where: { id: ctx.admin.id } });
  if (!admin || !verifyPassword(currentPassword, admin.passwordHash)) {
    await logActivity("password.change_failed", "wrong current password", getClientIp(request));
    return NextResponse.json({ error: "Your current password is incorrect." }, { status: 401 });
  }

  if (verifyPassword(newPassword, admin.passwordHash)) {
    return NextResponse.json({ error: "Choose a password different from the current one." }, { status: 400 });
  }

  await db.adminUser.update({
    where: { id: admin.id },
    data: { passwordHash: hashPassword(newPassword) },
  });

  // Security best practice: end every other session after a password change.
  const revoked = await revokeAllSessionsForAdmin(admin.id, ctx.sessionId);
  await logActivity("password.changed", `${revoked} other session(s) revoked`, getClientIp(request));

  return NextResponse.json({ ok: true, revokedOthers: revoked });
}
