import { NextResponse } from "next/server";
import { clearAllLockouts } from "@/lib/admin/rate-limit";
import { getClientIp, logActivity, passesCsrfChecks, requireAdmin } from "@/lib/admin/auth";

/** Admin-only: clear active login lockouts (fail2ban-style manual unban). */
export async function POST(request: Request) {
  const ctx = await requireAdmin(request);
  if (!ctx) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!passesCsrfChecks(request)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const cleared = clearAllLockouts();
  await logActivity("security.lockouts_cleared", `${cleared} lockout(s) cleared`, getClientIp(request));
  return NextResponse.json({ ok: true, cleared });
}
