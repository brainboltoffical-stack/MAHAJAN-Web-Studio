import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getClientIp, logActivity, passesCsrfChecks, requireAdmin } from "@/lib/admin/auth";

const VALID_STATUSES = ["New", "Contacted", "In Discussion", "Completed"];

type Params = { params: Promise<{ id: string }> };

/** Update a message: mark read/unread and/or change enquiry status. */
export async function PATCH(request: Request, { params }: Params) {
  const ctx = await requireAdmin(request);
  if (!ctx) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!passesCsrfChecks(request)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { id } = await params;
  const body = (await request.json().catch(() => ({}))) as { isRead?: boolean; status?: string };

  const existing = await db.projectInquiry.findUnique({ where: { id } });
  if (!existing) return NextResponse.json({ error: "Message not found" }, { status: 404 });

  const data: { isRead?: boolean; status?: string } = {};
  if (typeof body.isRead === "boolean") data.isRead = body.isRead;
  if (typeof body.status === "string" && VALID_STATUSES.includes(body.status)) data.status = body.status;

  if (Object.keys(data).length === 0) {
    return NextResponse.json({ error: "Nothing to update" }, { status: 400 });
  }

  const updated = await db.projectInquiry.update({ where: { id }, data });

  const changes = [
    typeof data.isRead === "boolean" && data.isRead !== existing.isRead
      ? `marked ${data.isRead ? "read" : "unread"}`
      : null,
    data.status && data.status !== existing.status ? `status ${existing.status} → ${data.status}` : null,
  ]
    .filter(Boolean)
    .join(", ");

  await logActivity("message.update", `${changes || "no change"} — from ${existing.name}`, getClientIp(request));
  return NextResponse.json({ ok: true, message: updated });
}

/** Permanently delete a message. */
export async function DELETE(request: Request, { params }: Params) {
  const ctx = await requireAdmin(request);
  if (!ctx) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!passesCsrfChecks(request)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const { id } = await params;
  const existing = await db.projectInquiry.findUnique({ where: { id } });
  if (!existing) return NextResponse.json({ error: "Message not found" }, { status: 404 });

  await db.projectInquiry.delete({ where: { id } });
  await logActivity(
    "message.delete",
    `deleted enquiry from ${existing.name} <${existing.email}>`,
    getClientIp(request)
  );
  return NextResponse.json({ ok: true });
}
