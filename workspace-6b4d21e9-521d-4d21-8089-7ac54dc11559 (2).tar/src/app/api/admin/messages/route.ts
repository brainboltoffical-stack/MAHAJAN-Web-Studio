import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/admin/auth";

const PAGE_SIZE = 10;

export async function GET(request: Request) {
  const ctx = await requireAdmin(request);
  if (!ctx) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const url = new URL(request.url);
  const q = (url.searchParams.get("q") ?? "").trim().slice(0, 100);
  const status = url.searchParams.get("status") ?? "all";
  const read = url.searchParams.get("read") ?? "all";
  const page = Math.max(1, parseInt(url.searchParams.get("page") ?? "1", 10) || 1);

  const where: Record<string, unknown> = {};
  if (q) {
    where.OR = [
      { name: { contains: q } },
      { email: { contains: q } },
      { businessName: { contains: q } },
    ];
  }
  if (["New", "Contacted", "In Discussion", "Completed"].includes(status)) {
    where.status = status;
  }
  if (read === "read") where.isRead = true;
  if (read === "unread") where.isRead = false;

  const [total, messages, unreadCount, statusGroups] = await Promise.all([
    db.projectInquiry.count({ where }),
    db.projectInquiry.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * PAGE_SIZE,
      take: PAGE_SIZE,
    }),
    db.projectInquiry.count({ where: { isRead: false } }),
    db.projectInquiry.groupBy({ by: ["status"], _count: { _all: true } }),
  ]);

  return NextResponse.json({
    messages,
    total,
    page,
    pageSize: PAGE_SIZE,
    pages: Math.max(1, Math.ceil(total / PAGE_SIZE)),
    unreadCount,
    statusCounts: Object.fromEntries(statusGroups.map((g) => [g.status, g._count._all])),
  });
}
