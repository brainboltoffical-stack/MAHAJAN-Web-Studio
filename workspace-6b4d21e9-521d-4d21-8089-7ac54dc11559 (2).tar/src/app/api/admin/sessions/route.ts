import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  getClientIp,
  logActivity,
  passesCsrfChecks,
  requireAdmin,
  revokeAllSessionsForAdmin,
  revokeSession,
} from "@/lib/admin/auth";

/** List all live (non-revoked, non-expired) sessions for the current admin. */
export async function GET(request: Request) {
  const ctx = await requireAdmin(request);
  if (!ctx) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const sessions = await db.session.findMany({
    where: { adminId: ctx.admin.id, revokedAt: null, expiresAt: { gt: new Date() } },
    orderBy: { createdAt: "desc" },
    select: { id: true, userAgent: true, createdAt: true, expiresAt: true, ipHash: true },
  });

  return NextResponse.json({
    sessions: sessions.map((s) => ({ ...s, current: s.id === ctx.sessionId })),
  });
}

/** Revoke one session (?id=) or all other sessions (?scope=others). */
export async function DELETE(request: Request) {
  const ctx = await requireAdmin(request);
  if (!ctx) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!passesCsrfChecks(request)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const url = new URL(request.url);
  const id = url.searchParams.get("id");
  const scope = url.searchParams.get("scope");

  if (scope === "others") {
    const count = await revokeAllSessionsForAdmin(ctx.admin.id, ctx.sessionId);
    await logActivity("sessions.revoked_others", `${count} session(s) revoked`, getClientIp(request));
    return NextResponse.json({ ok: true, revoked: count });
  }

  if (id) {
    const session = await db.session.findFirst({ where: { id, adminId: ctx.admin.id } });
    if (!session) return NextResponse.json({ error: "Session not found" }, { status: 404 });
    await revokeSession(id);
    await logActivity(
      "session.revoked",
      id === ctx.sessionId ? "revoked own session" : "revoked another session",
      getClientIp(request)
    );
    return NextResponse.json({ ok: true, self: id === ctx.sessionId });
  }

  return NextResponse.json({ error: "Provide ?id= or ?scope=others" }, { status: 400 });
}
