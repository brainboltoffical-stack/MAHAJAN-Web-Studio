import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  createSession,
  getClientIp,
  ipHash,
  logActivity,
  sessionCookieOptions,
  SESSION_COOKIE,
  verifyPassword,
} from "@/lib/admin/auth";
import {
  isLockedOut,
  loginFailureKey,
  LOGIN_MAX_FAILURES,
  rateLimit,
  recordLoginFailure,
  resetLoginFailures,
} from "@/lib/admin/rate-limit";
import { notifySecurityAlert } from "@/lib/admin/mailer";

/**
 * Admin login.
 * - Generic error messages (no user enumeration).
 * - IP throttle + per-identifier/IP lockout after 5 failed attempts (15 min).
 * - Every attempt is recorded in LoginAttempt (success/fail, no passwords).
 */
export async function POST(request: Request) {
  try {
    const ip = getClientIp(request) ?? "unknown";

    const ipThrottle = rateLimit(`login-ip:${ip}`, 20, 15 * 60 * 1000);
    if (!ipThrottle.allowed) {
      return NextResponse.json(
        { error: `Too many login attempts. Try again in ${Math.ceil(ipThrottle.retryAfterSec / 60)} minutes.` },
        { status: 429 }
      );
    }

    const body = (await request.json().catch(() => ({}))) as { identifier?: string; password?: string };
    const identifier = (body.identifier ?? "").trim().slice(0, 160);
    const password = typeof body.password === "string" ? body.password.slice(0, 200) : "";

    if (!identifier || !password) {
      return NextResponse.json({ error: "Please enter your username/email and password." }, { status: 400 });
    }

    const failureKey = loginFailureKey(identifier, ip);
    const lock = isLockedOut(failureKey);
    if (lock.locked) {
      await logActivity("login.locked_out", `identifier=${identifier}`, ip);
      return NextResponse.json(
        {
          error: `Account temporarily locked after ${LOGIN_MAX_FAILURES} failed attempts. Try again in ${Math.ceil(lock.retryAfterSec / 60)} minutes.`,
          retryAfterSec: lock.retryAfterSec,
        },
        { status: 429 }
      );
    }

    // Lookup by email OR username (username matched case-insensitively).
    const admin = await db.adminUser.findFirst({
      where: {
        OR: [{ email: identifier.toLowerCase() }, { username: { in: [identifier, identifier.toLowerCase()] } }],
      },
    });

    const passwordOk = admin ? verifyPassword(password, admin.passwordHash) : false;
    const userAgent = request.headers.get("user-agent");

    if (!admin || !passwordOk) {
      recordLoginFailure(failureKey);
      await db.loginAttempt.create({
        data: {
          username: identifier.slice(0, 100),
          success: false,
          ipHash: ipHash(ip),
          userAgent: userAgent ? userAgent.slice(0, 300) : null,
        },
      });

      const nowLocked = isLockedOut(failureKey);
      if (nowLocked.locked) {
        await logActivity("login.locked_out", `identifier=${identifier}`, ip);
        void notifySecurityAlert(
          `Identifier: ${identifier}. The account is temporarily locked for 15 minutes after ${LOGIN_MAX_FAILURES} failed attempts.`
        ).catch(() => undefined);
      }

      return NextResponse.json({ error: "Invalid credentials. All attempts are logged." }, { status: 401 });
    }

    resetLoginFailures(failureKey);
    const { token } = await createSession({ adminId: admin.id, ip, userAgent });
    await db.loginAttempt.create({
      data: {
        username: identifier.slice(0, 100),
        success: true,
        ipHash: ipHash(ip),
        userAgent: userAgent ? userAgent.slice(0, 300) : null,
      },
    });
    await logActivity("login.success", `admin=${admin.username}`, ip);

    const response = NextResponse.json({ ok: true });
    response.cookies.set(SESSION_COOKIE, token, sessionCookieOptions());
    return response;
  } catch (error) {
    console.error("[/api/admin/login] error:", error);
    return NextResponse.json({ error: "Login is temporarily unavailable. Please try again." }, { status: 500 });
  }
}
