import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getClientIp, logActivity, passesCsrfChecks, requireAdmin } from "@/lib/admin/auth";
import { istDayStart } from "@/lib/admin/tracking";
import { notifySecurityAlert } from "@/lib/admin/mailer";

export async function GET(request: Request) {
  const ctx = await requireAdmin(request);
  if (!ctx) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const now = new Date();
  const todayStart = istDayStart(now);
  const weekStart = new Date(todayStart.getTime() - 6 * 24 * 60 * 60 * 1000);
  const monthStart = (() => {
    const shifted = new Date(now.getTime() + 330 * 60000);
    shifted.setUTCDate(1);
    shifted.setUTCHours(0, 0, 0, 0);
    return new Date(shifted.getTime() - 330 * 60000);
  })();

  const [totalPageViews, totalInquiries, unreadMessages, dailyRows, monthRows, allRows, recentMessages, statusGroups, recentFailures, lastSecurityAlert] =
    await Promise.all([
      db.pageView.count(),
      db.projectInquiry.count(),
      db.projectInquiry.count({ where: { isRead: false } }),
      db.pageView.findMany({
        where: { createdAt: { gte: new Date(todayStart.getTime() - 13 * 24 * 60 * 60 * 1000) } },
        select: { visitorDaily: true, createdAt: true },
      }),
      db.pageView.findMany({
        where: { createdAt: { gte: monthStart } },
        select: { visitorDaily: true, visitorMonthly: true, createdAt: true },
      }),
      db.pageView.findMany({ select: { visitorDaily: true, visitorMonthly: true } }),
      db.projectInquiry.findMany({ orderBy: { createdAt: "desc" }, take: 5 }),
      db.projectInquiry.groupBy({ by: ["status"], _count: { _all: true } }),
      db.loginAttempt.findMany({
        where: { success: false, createdAt: { gte: new Date(now.getTime() - 15 * 60 * 1000) } },
        select: { id: true },
      }),
      db.notificationLog.findFirst({
        where: { type: "security_alert", createdAt: { gte: new Date(now.getTime() - 60 * 60 * 1000) } },
        select: { id: true },
      }),
    ]);

  // Aggregate in JS (dataset is small; keeps SQLite simple and portable).
  const distinct = (rows: { visitorDaily: string }[]) => new Set(rows.map((r) => r.visitorDaily)).size;

  const todayRows = dailyRows.filter((r) => r.createdAt >= todayStart);
  const weekRows = dailyRows.filter((r) => r.createdAt >= weekStart);

  // 14-day trend
  const trend: { date: string; visitors: number; views: number }[] = [];
  for (let i = 13; i >= 0; i--) {
    const dayStart = new Date(todayStart.getTime() - i * 24 * 60 * 60 * 1000);
    const dayEnd = new Date(dayStart.getTime() + 24 * 60 * 60 * 1000);
    const rows = dailyRows.filter((r) => r.createdAt >= dayStart && r.createdAt < dayEnd);
    const shifted = new Date(dayStart.getTime() + 330 * 60000);
    trend.push({
      date: shifted.toISOString().slice(5, 10),
      visitors: distinct(rows),
      views: rows.length,
    });
  }

  const statusCounts = Object.fromEntries(statusGroups.map((g) => [g.status, g._count._all])) as Record<string, number>;

  // Suspicious activity: >=5 failed logins in 15 min → alert (max once per hour).
  const securityAlert = recentFailures.length >= 5;
  let alertNotified = false;
  if (securityAlert && !lastSecurityAlert) {
    void notifySecurityAlert(`${recentFailures.length} failed login attempts in the last 15 minutes.`).catch(() => undefined);
    await logActivity("security.alert_raised", `${recentFailures.length} failed attempts in 15 min`, getClientIp(request));
    alertNotified = true;
  }

  return NextResponse.json({
    stats: {
      totalVisitors: distinct(allRows),
      uniqueVisitors: new Set(allRows.map((r) => r.visitorMonthly)).size,
      totalPageViews,
      todayVisitors: distinct(todayRows),
      weekVisitors: distinct(weekRows),
      monthVisitors: distinct(monthRows),
      totalInquiries,
      unreadMessages,
    },
    trend,
    statusCounts,
    recentMessages,
    security: {
      failedAttempts15m: recentFailures.length,
      alert: securityAlert,
      alertNotified,
    },
  });
}

export async function POST(request: Request) {
  // CSRF probe — GET is used for reads; reject stray POSTs loudly.
  if (!passesCsrfChecks(request)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  return NextResponse.json({ error: "Not supported" }, { status: 405 });
}
