import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { rateLimit } from "@/lib/admin/rate-limit";
import { getClientIp, ipHash } from "@/lib/admin/auth";
import { notifyNewEnquiry } from "@/lib/admin/mailer";
import { detectDevice } from "@/lib/admin/tracking";
import { z } from "zod";

const VALID_STATUSES = ["New", "Contacted", "In Discussion", "Completed"];

const inquirySchema = z.object({
  name: z.string().trim().min(2).max(80),
  businessName: z.string().trim().max(120).optional().or(z.literal("")),
  email: z.email().max(160),
  websiteType: z.string().trim().min(2).max(60),
  description: z.string().trim().min(10).max(4000),
  // Anti-spam fields (honeypot + time trap). Real users never fill them manually.
  website_url: z.string().max(200).optional().or(z.literal("")),
  startedAt: z.number().int().optional(),
});

/** Fake-success response — never reveals to bots that they were filtered. */
function spamOk() {
  return NextResponse.json({ ok: true }, { status: 201 });
}

export async function POST(request: Request) {
  try {
    const ip = getClientIp(request);

    // Per-IP throttle: max 5 submissions per hour.
    const limit = rateLimit(`inquiry:${ipHash(ip) ?? "unknown"}`, 5, 60 * 60 * 1000);
    if (!limit.allowed) {
      return NextResponse.json(
        {
          ok: false,
          error: `Too many submissions from your network. Please try again in about ${Math.ceil(limit.retryAfterSec / 60)} minutes or email us directly.`,
        },
        { status: 429 }
      );
    }

    const body = await request.json().catch(() => null);
    if (!body) {
      return NextResponse.json({ ok: false, error: "Invalid request." }, { status: 400 });
    }

    // Honeypot: hidden field that only bots fill. Silently discard.
    if (typeof body.website_url === "string" && body.website_url.trim().length > 0) {
      return spamOk();
    }

    // Time trap: submissions faster than 1.5s after render are automated.
    if (typeof body.startedAt !== "number" || Date.now() - body.startedAt < 1500 || Date.now() - body.startedAt > 86_400_000) {
      return spamOk();
    }

    const parsed = inquirySchema.safeParse(body);
    if (!parsed.success) {
      const flat = z.flattenError(parsed.error);
      return NextResponse.json(
        {
          ok: false,
          error: "Please check the form fields and try again.",
          issues: flat.fieldErrors,
        },
        { status: 400 }
      );
    }

    const data = parsed.data;
    const userAgent = request.headers.get("user-agent");

    const inquiry = await db.projectInquiry.create({
      data: {
        name: data.name,
        businessName: data.businessName || null,
        email: data.email,
        websiteType: data.websiteType,
        description: data.description,
        ipHash: ipHash(ip),
        userAgent: userAgent ? userAgent.slice(0, 300) : null,
      },
    });

    // Email notification — recorded as "skipped" when no provider is configured.
    void notifyNewEnquiry({
      name: data.name,
      businessName: data.businessName,
      email: data.email,
      websiteType: data.websiteType,
      description: data.description,
      createdAt: inquiry.createdAt,
    }).catch(() => undefined);

    void VALID_STATUSES; // statuses are managed from the admin inbox
    void detectDevice; // device detection is used by analytics, kept here for parity

    return NextResponse.json({ ok: true, id: inquiry.id }, { status: 201 });
  } catch (error) {
    console.error("[/api/inquiry] Failed to save inquiry:", error);
    return NextResponse.json(
      {
        ok: false,
        error:
          "We could not receive your inquiry right now. Please email us directly at brainboltoffical@gmail.com.",
      },
      { status: 500 }
    );
  }
}
