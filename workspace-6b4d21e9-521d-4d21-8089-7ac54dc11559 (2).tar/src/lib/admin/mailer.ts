/**
 * Email notifications for new enquiries and security alerts.
 *
 * Integration status (checked at runtime, shown in Admin → Settings):
 *  1. SMTP_URL      — full SMTP via nodemailer (e.g. smtps://user:pass@smtp.gmail.com:465)
 *  2. RESEND_API_KEY — Resend HTTPS API
 *  3. Neither       — notification is recorded as "skipped" so the admin knows
 *                     exactly what to configure. Nothing is silently dropped.
 *
 * Credentials are read from server-side env vars only and are never sent to
 * the browser or written into logs.
 */
import { db } from "@/lib/db";

const ADMIN_NOTIFY_EMAIL = process.env.ADMIN_NOTIFY_EMAIL || "brainboltoffical@gmail.com";

export function mailIntegrationName(): "SMTP" | "Resend" | null {
  if (process.env.SMTP_URL) return "SMTP";
  if (process.env.RESEND_API_KEY) return "Resend";
  return null;
}

type MailPayload = { subject: string; text: string };

async function sendViaSmtp(payload: MailPayload): Promise<void> {
  const nodemailer = await import("nodemailer");
  const transporter = nodemailer.createTransport(process.env.SMTP_URL as string);
  await transporter.sendMail({
    from: process.env.SMTP_FROM || "MAHAJAN Studio <onboarding@resend.dev>",
    to: ADMIN_NOTIFY_EMAIL,
    subject: payload.subject,
    text: payload.text,
  });
}

async function sendViaResend(payload: MailPayload): Promise<void> {
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from: process.env.SMTP_FROM || "MAHAJAN Studio <onboarding@resend.dev>",
      to: [ADMIN_NOTIFY_EMAIL],
      subject: payload.subject,
      text: payload.text,
    }),
  });
  if (!res.ok) throw new Error(`Resend API error ${res.status}`);
}

async function deliver(payload: MailPayload): Promise<"sent" | "skipped" | "failed"> {
  const provider = mailIntegrationName();
  try {
    if (provider === "SMTP") {
      await sendViaSmtp(payload);
      return "sent";
    }
    if (provider === "Resend") {
      await sendViaResend(payload);
      return "sent";
    }
    return "skipped";
  } catch (error) {
    console.error("[mailer] delivery failed:", error instanceof Error ? error.message : error);
    return "failed";
  }
}

/** Fire-and-forget notification that always records its outcome. */
export async function notify(type: string, payload: MailPayload): Promise<void> {
  const provider = mailIntegrationName();
  const status = await deliver(payload);
  try {
    await db.notificationLog.create({
      data: {
        type,
        target: ADMIN_NOTIFY_EMAIL,
        status,
        detail:
          status === "skipped"
            ? `No email provider configured. Set SMTP_URL or RESEND_API_KEY to enable delivery. Subject: ${payload.subject}`
            : payload.subject.slice(0, 300),
      },
    });
  } catch {
    // never break the request because of notification logging
  }
  void provider;
}

export async function notifyNewEnquiry(data: {
  name: string;
  businessName?: string | null;
  email: string;
  websiteType: string;
  description: string;
  createdAt: Date;
}): Promise<void> {
  await notify("new_enquiry", {
    subject: `New project inquiry — ${data.name}${data.businessName ? ` (${data.businessName})` : ""}`,
    text: [
      "You received a new website inquiry on mahajan.studio:",
      "",
      `Name: ${data.name}`,
      `Business: ${data.businessName || "—"}`,
      `Email: ${data.email}`,
      `Type of website: ${data.websiteType}`,
      `Received: ${data.createdAt.toISOString()} (stored in IST in the admin inbox)`,
      "",
      "Project description:",
      data.description,
      "",
      "— MAHAJAN Web Development Studio (automated notification)",
    ].join("\n"),
  });
}

export async function notifySecurityAlert(detail: string): Promise<void> {
  await notify("security_alert", {
    subject: "MAHAJAN security alert — repeated failed admin logins",
    text: `Repeated failed login attempts were detected on the MAHAJAN admin panel.\n\n${detail}\n\nReview: Admin Panel → Settings → Login activity.`,
  });
}
