/**
 * MAHAJAN admin authentication & session security.
 *
 * - Passwords: scrypt (salted, timing-safe comparison). Never stored or logged in plaintext.
 * - Sessions: signed JWT (HS256) in an HTTP-only cookie + server-side session row
 *   (allows instant revocation). Every admin API verifies the session on the server.
 * - Secrets: read from server-side env only; never bundled into client code.
 */
import { createHash, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { SignJWT, jwtVerify } from "jose";
import { db } from "@/lib/db";

export const SESSION_COOKIE = "mahajan_admin";
export const SESSION_TTL_SECONDS = 60 * 60 * 24 * 7; // 7 days

const encoder = new TextEncoder();

function getSecretKey(): Uint8Array {
  let secret = process.env.AUTH_SECRET;
  if (!secret || secret.length < 16) {
    // Deterministic dev fallback so the sandbox keeps working across restarts.
    // Production MUST set AUTH_SECRET in the server environment.
    secret = createHash("sha256")
      .update(`mahajan-dev-fallback:${process.env.DATABASE_URL ?? ""}`)
      .digest("hex");
  }
  return encoder.encode(secret);
}

/* ----------------------------- passwords ----------------------------- */

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `s1$${salt}$${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [version, salt, hash] = stored.split("$");
    if (version !== "s1" || !salt || !hash) return false;
    const derived = scryptSync(password, salt, 64);
    const original = Buffer.from(hash, "hex");
    return original.length === derived.length && timingSafeEqual(original, derived);
  } catch {
    return false;
  }
}

/* --------------------------- pseudonymisation -------------------------- */

/** One-way hash of the IP with a server-side pepper. Raw IPs are never stored. */
export function ipHash(ip: string | null | undefined): string | null {
  if (!ip) return null;
  return createHash("sha256").update(`ip:${ip}:${getSecretKey()}`).digest("hex").slice(0, 24);
}

export function getClientIp(req: Request): string | null {
  const xff = req.headers.get("x-forwarded-for");
  if (xff) return xff.split(",")[0].trim();
  return req.headers.get("x-real-ip");
}

/* ------------------------------ sessions ------------------------------ */

export type SessionContext = {
  admin: { id: string; username: string; email: string };
  sessionId: string;
};

async function signSessionJwt(sessionId: string): Promise<string> {
  return new SignJWT({ sid: sessionId })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(`${SESSION_TTL_SECONDS}s`)
    .sign(getSecretKey());
}

export async function verifySessionJwt(token: string): Promise<string | null> {
  try {
    const { payload } = await jwtVerify(token, getSecretKey());
    return typeof payload.sid === "string" ? payload.sid : null;
  } catch {
    return null;
  }
}

export async function createSession(opts: {
  adminId: string;
  ip: string | null;
  userAgent: string | null;
}): Promise<{ token: string; expiresAt: Date }> {
  const sessionId = randomBytes(24).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_TTL_SECONDS * 1000);
  await db.session.create({
    data: {
      id: sessionId,
      adminId: opts.adminId,
      userAgent: opts.userAgent ? opts.userAgent.slice(0, 300) : null,
      ipHash: ipHash(opts.ip),
      expiresAt,
    },
  });
  const token = await signSessionJwt(sessionId);
  return { token, expiresAt };
}

/** Verify cookie JWT AND the server-side session row (revocation-aware). */
export async function getSessionContext(token: string | undefined): Promise<SessionContext | null> {
  if (!token) return null;
  const sid = await verifySessionJwt(token);
  if (!sid) return null;

  const session = await db.session.findUnique({
    where: { id: sid },
    include: { admin: true },
  });
  if (!session || session.revokedAt || session.expiresAt <= new Date()) return null;

  return {
    admin: {
      id: session.admin.id,
      username: session.admin.username,
      email: session.admin.email,
    },
    sessionId: session.id,
  };
}

export function readSessionCookie(req: Request): string | undefined {
  const cookieHeader = req.headers.get("cookie");
  if (!cookieHeader) return undefined;
  for (const part of cookieHeader.split(";")) {
    const [name, ...rest] = part.trim().split("=");
    if (name === SESSION_COOKIE) return rest.join("=");
  }
  return undefined;
}

/** Server-side gate used by EVERY admin API route. */
export async function requireAdmin(req: Request): Promise<SessionContext | null> {
  return getSessionContext(readSessionCookie(req));
}

export async function revokeSession(sessionId: string): Promise<void> {
  await db.session.updateMany({
    where: { id: sessionId, revokedAt: null },
    data: { revokedAt: new Date() },
  });
}

export async function revokeAllSessionsForAdmin(adminId: string, exceptSessionId?: string): Promise<number> {
  const result = await db.session.updateMany({
    where: {
      adminId,
      revokedAt: null,
      ...(exceptSessionId ? { id: { not: exceptSessionId } } : {}),
    },
    data: { revokedAt: new Date() },
  });
  return result.count;
}

export function sessionCookieOptions() {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: SESSION_TTL_SECONDS,
  };
}

/* --------------------------- CSRF protections --------------------------- */

/**
 * Mutating admin requests must (1) be same-origin and (2) carry a custom
 * header that cross-site forms cannot add without a CORS preflight.
 *
 * Behind rewriting proxies (e.g. the sandbox preview gateway) the original
 * public Host never reaches the app, so an explicit server-side allowlist
 * (ADMIN_TRUSTED_ORIGINS, comma-separated) marks origins the operator trusts.
 */
export function passesCsrfChecks(req: Request): boolean {
  if (req.headers.get("x-mahajan-admin") !== "1") return false;
  const origin = req.headers.get("origin");
  if (!origin) return true;
  let originHost: string;
  try {
    originHost = new URL(origin).host;
  } catch {
    return false;
  }
  const hostCandidates = [req.headers.get("host"), req.headers.get("x-forwarded-host")].filter(
    (h): h is string => Boolean(h),
  );
  if (hostCandidates.includes(originHost)) return true;
  const trustedOrigins = (process.env.ADMIN_TRUSTED_ORIGINS ?? "")
    .split(",")
    .map((entry) => entry.trim())
    .filter(Boolean);
  for (const trusted of trustedOrigins) {
    try {
      if (new URL(trusted).host === originHost) return true;
    } catch {
      // ignore malformed allowlist entries
    }
  }
  return false;
}

/* ------------------------------ activity log ------------------------------ */

export async function logActivity(action: string, detail?: string, ip?: string | null): Promise<void> {
  try {
    await db.adminActivityLog.create({
      data: { action, detail: detail?.slice(0, 500) ?? null, ipHash: ipHash(ip) },
    });
  } catch {
    // logging must never break the request
  }
}
