"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

/**
 * Consistent section heading: small eyebrow label, display title and
 * optional supporting subtitle.
 */
export function SectionHeading({
  eyebrow,
  title,
  subtitle,
  align = "center",
  className,
}: {
  eyebrow: string;
  title: React.ReactNode;
  subtitle?: string;
  align?: "center" | "left";
  className?: string;
}) {
  const alignCls = align === "center" ? "items-center text-center mx-auto" : "items-start text-left";
  return (
    <motion.div
      className={cn("flex max-w-2xl flex-col", alignCls, className)}
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-70px" }}
      transition={{ duration: 0.7, ease: [0.21, 0.47, 0.32, 0.98] }}
    >
      <span className="mb-4 inline-flex items-center gap-2 rounded-full border border-electric-500/30 bg-electric-500/10 px-3.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.22em] text-electric-400">
        <span className="h-1.5 w-1.5 rounded-full bg-electric-400 animate-pulse-dot" />
        {eyebrow}
      </span>
      <h2 className="font-display text-3xl font-bold leading-[1.15] tracking-tight text-white sm:text-4xl lg:text-[2.75rem]">
        {title}
      </h2>
      {subtitle && (
        <p className="mt-4 text-base leading-relaxed text-muted-foreground sm:text-lg">{subtitle}</p>
      )}
    </motion.div>
  );
}
