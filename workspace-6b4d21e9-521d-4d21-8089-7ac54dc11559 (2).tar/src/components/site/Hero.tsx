"use client";

import { motion } from "framer-motion";
import { ArrowRight, MonitorSmartphone, Search, Smartphone, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.12, delayChildren: 0.1 } },
};

const item = {
  hidden: { opacity: 0, y: 26 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.75, ease: [0.21, 0.47, 0.32, 0.98] as const },
  },
};

const HONEST_STATS = [
  { value: "6", label: "Services Tailored to Small Business" },
  { value: "3", label: "Demo & Concept Projects" },
  { value: "4", label: "Countries Served — UK · US · CA · AU" },
];

export function Hero() {
  return (
    <section id="home" className="relative overflow-hidden pt-[76px]" aria-label="Introduction">
      {/* Backdrop: blueprint grid + electric glow orbs */}
      <div className="bg-grid bg-grid-fade absolute inset-0" aria-hidden />
      <div
        className="absolute -top-40 left-1/2 h-[560px] w-[820px] -translate-x-1/2 rounded-full bg-electric-600/20 blur-[140px]"
        aria-hidden
      />
      <div
        className="absolute right-[-180px] top-1/3 h-[380px] w-[380px] rounded-full bg-electric-500/10 blur-[120px]"
        aria-hidden
      />

      <div className="relative mx-auto grid w-full max-w-7xl items-center gap-14 px-5 pb-20 pt-14 sm:px-8 lg:grid-cols-[1.05fr_0.95fr] lg:gap-10 lg:pb-28 lg:pt-24">
        {/* Copy */}
        <motion.div variants={container} initial="hidden" animate="show" className="max-w-2xl">
          <motion.div variants={item}>
            <span className="inline-flex items-center gap-2.5 rounded-full border border-white/10 bg-white/[0.04] px-4 py-2 text-xs font-medium tracking-wide text-muted-foreground">
              <span className="h-2 w-2 rounded-full bg-electric-400 animate-pulse-dot" aria-hidden />
              Web Design &amp; Development Studio
              <span className="hidden text-white/25 sm:inline">|</span>
              <span className="hidden sm:inline text-foreground/80">Serving UK · USA · Canada · Australia</span>
            </span>
          </motion.div>

          <motion.h1
            variants={item}
            className="mt-7 font-display text-[2.6rem] font-bold leading-[1.06] tracking-tight text-white sm:text-6xl lg:text-[4.15rem]"
          >
            We Build <span className="text-gradient-electric">Modern Websites</span> for Growing
            Businesses.
          </motion.h1>

          <motion.p
            variants={item}
            className="mt-6 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg"
          >
            Helping small businesses build a strong digital presence through modern, responsive and
            professional websites.
          </motion.p>

          <motion.div variants={item} className="mt-9 flex flex-wrap items-center gap-4">
            <Button
              asChild
              size="lg"
              className="glow-electric h-12 rounded-full bg-electric-500 px-7 text-[15px] font-semibold text-white hover:bg-electric-600"
            >
              <a href="#work">
                View Our Work
                <ArrowRight className="ml-2 h-4 w-4" aria-hidden />
              </a>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="h-12 rounded-full border-white/20 bg-white/[0.03] px-7 text-[15px] font-semibold text-white hover:border-electric-500/60 hover:bg-electric-500/10 hover:text-white"
            >
              <a href="#contact">Start Your Project</a>
            </Button>
          </motion.div>

          {/* Honest stats — no invented clients or reviews */}
          <motion.dl
            variants={item}
            className="mt-12 grid grid-cols-1 gap-6 border-t border-white/[0.07] pt-8 sm:grid-cols-3"
          >
            {HONEST_STATS.map((stat) => (
              <div key={stat.label} className="flex flex-col gap-1.5">
                <dt className="sr-only">{stat.label}</dt>
                <dd className="font-display text-3xl font-bold text-white">
                  {stat.value}
                  <span className="text-electric-400">+</span>
                </dd>
                <dd className="text-[13px] leading-snug text-muted-foreground">{stat.label}</dd>
              </div>
            ))}
          </motion.dl>
        </motion.div>

        {/* Visual: stylised browser preview built with CSS */}
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 30 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.35, ease: [0.21, 0.47, 0.32, 0.98] }}
          className="relative mx-auto hidden w-full max-w-[540px] sm:block lg:max-w-none"
          aria-hidden
        >
          {/* Glow behind window */}
          <div className="glow-electric-lg absolute -inset-6 rounded-[28px] bg-electric-600/10 blur-2xl" />

          <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-[#0b0e16]/90 shadow-[0_40px_120px_-30px_rgba(0,0,0,0.9)]">
            {/* Browser chrome */}
            <div className="flex items-center gap-3 border-b border-white/[0.07] bg-white/[0.03] px-4 py-3">
              <div className="flex gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-[#ff5f57]" />
                <span className="h-2.5 w-2.5 rounded-full bg-[#febc2e]" />
                <span className="h-2.5 w-2.5 rounded-full bg-[#28c840]" />
              </div>
              <div className="flex flex-1 items-center gap-2 rounded-md bg-black/40 px-3 py-1.5 text-[11px] text-muted-foreground">
                <Search className="h-3 w-3" />
                yourbusiness.com — modern &amp; responsive
              </div>
            </div>

            {/* Mini site preview */}
            <div className="space-y-4 p-5">
              {/* mini nav */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="h-5 w-5 rounded-md bg-gradient-to-br from-electric-300 to-electric-600" />
                  <span className="h-2 w-14 rounded-full bg-white/25" />
                </div>
                <div className="flex items-center gap-2.5">
                  <span className="h-1.5 w-8 rounded-full bg-white/15" />
                  <span className="h-1.5 w-8 rounded-full bg-white/15" />
                  <span className="h-5 w-14 rounded-full bg-electric-500/90" />
                </div>
              </div>
              {/* mini hero */}
              <div className="rounded-xl border border-white/[0.06] bg-gradient-to-br from-electric-600/25 via-[#0e1424] to-[#0b0e16] p-5">
                <div className="h-2 w-24 rounded-full bg-electric-400/70" />
                <div className="mt-3 h-3.5 w-4/5 rounded-full bg-white/30" />
                <div className="mt-2 h-3.5 w-3/5 rounded-full bg-white/20" />
                <div className="mt-2 h-2 w-2/3 rounded-full bg-white/10" />
                <div className="mt-4 flex gap-2">
                  <span className="h-6 w-20 rounded-full bg-electric-500" />
                  <span className="h-6 w-20 rounded-full border border-white/20" />
                </div>
              </div>
              {/* mini cards */}
              <div className="grid grid-cols-3 gap-3">
                {[0, 1, 2].map((i) => (
                  <div
                    key={i}
                    className="rounded-lg border border-white/[0.06] bg-white/[0.03] p-3"
                  >
                    <span className="block h-6 w-6 rounded-md bg-electric-500/30" />
                    <span className="mt-2.5 block h-1.5 w-full rounded-full bg-white/20" />
                    <span className="mt-1.5 block h-1.5 w-2/3 rounded-full bg-white/10" />
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Floating feature chips */}
          <div className="animate-float absolute -right-4 top-14 hidden items-center gap-2 rounded-xl border border-white/10 bg-[#0d1019]/95 px-3.5 py-2.5 shadow-xl backdrop-blur md:flex">
            <Smartphone className="h-4 w-4 text-electric-400" />
            <div className="text-[11px] leading-tight">
              <p className="font-semibold text-white">Fully Responsive</p>
              <p className="text-muted-foreground">Mobile · Tablet · Desktop</p>
            </div>
          </div>
          <div
            className="animate-float absolute -left-6 bottom-20 hidden items-center gap-2 rounded-xl border border-white/10 bg-[#0d1019]/95 px-3.5 py-2.5 shadow-xl backdrop-blur md:flex"
            style={{ animationDelay: "1.6s" }}
          >
            <Zap className="h-4 w-4 text-electric-400" />
            <div className="text-[11px] leading-tight">
              <p className="font-semibold text-white">Fast Loading</p>
              <p className="text-muted-foreground">Performance-focused builds</p>
            </div>
          </div>
          <div
            className="animate-float absolute -bottom-6 right-10 hidden items-center gap-2 rounded-xl border border-white/10 bg-[#0d1019]/95 px-3.5 py-2.5 shadow-xl backdrop-blur md:flex"
            style={{ animationDelay: "3s" }}
          >
            <MonitorSmartphone className="h-4 w-4 text-electric-400" />
            <div className="text-[11px] leading-tight">
              <p className="font-semibold text-white">Modern Design</p>
              <p className="text-muted-foreground">Clean, premium interfaces</p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Service ticker */}
      <div className="relative border-y border-white/[0.07] bg-white/[0.015] py-4">
        <div className="overflow-hidden" aria-hidden>
          <div className="marquee-track flex w-max items-center gap-8 pr-8">
            {[0, 1].map((copy) => (
              <div key={copy} className="flex items-center gap-8">
                {[
                  "Business Websites",
                  "E-Commerce Stores",
                  "Shopify Design",
                  "Website Redesigns",
                  "Responsive Design",
                  "Landing Pages",
                ].map((label) => (
                  <span
                    key={`${copy}-${label}`}
                    className="flex items-center gap-8 whitespace-nowrap font-display text-[13px] font-medium uppercase tracking-[0.24em] text-white/45"
                  >
                    {label}
                    <span className="h-1.5 w-1.5 rounded-full bg-electric-500/80" />
                  </span>
                ))}
              </div>
            ))}
          </div>
        </div>
        <span className="sr-only">
          Services: business websites, e-commerce stores, Shopify design, website redesigns,
          responsive design and landing pages.
        </span>
      </div>
    </section>
  );
}
