"use client";

import { Compass, PenTool, Code2, Rocket } from "lucide-react";
import { SectionHeading } from "@/components/site/SectionHeading";
import { Reveal } from "@/components/site/Reveal";

const STEPS = [
  {
    number: "01",
    icon: Compass,
    title: "Understand the Business",
    description:
      "We start with a real conversation about your business, your customers and your goals. Before any design work begins, we make sure we understand what success looks like for you.",
  },
  {
    number: "02",
    icon: PenTool,
    title: "Design the Website",
    description:
      "We create a clean, modern design that matches your brand and speaks to your customers. You review it, share feedback and we refine it together until it feels exactly right.",
  },
  {
    number: "03",
    icon: Code2,
    title: "Develop & Test",
    description:
      "We build your website with modern, reliable technology and test it thoroughly on phones, tablets and desktops — checking speed, usability and every small detail.",
  },
  {
    number: "04",
    icon: Rocket,
    title: "Deliver the Website",
    description:
      "Once you are happy, we launch your website and hand over everything you need. We remain available for questions, updates and future improvements as your business grows.",
  },
];

export function Process() {
  return (
    <section id="process" className="relative py-24 lg:py-32" aria-label="Our work process">
      <div className="relative mx-auto w-full max-w-7xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="How We Work"
          title={
            <>
              A Simple, Transparent <span className="text-gradient-electric">Process</span>
            </>
          }
          subtitle="No confusion, no jargon — four clear steps from our first conversation to your finished website."
        />

        <div className="relative mt-16">
          {/* Connecting line (desktop) */}
          <div
            className="absolute left-0 right-0 top-[26px] hidden h-px bg-gradient-to-r from-transparent via-electric-500/40 to-transparent lg:block"
            aria-hidden
          />
          <ol className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4 lg:gap-6">
            {STEPS.map((step, i) => (
              <Reveal key={step.number} delay={i * 0.12}>
                <li className="group relative flex h-full flex-col">
                  <div className="relative z-10 mb-6 flex items-center gap-4">
                    <div className="flex h-[52px] w-[52px] items-center justify-center rounded-2xl border border-electric-500/30 bg-[#0b0e16] shadow-[0_0_0_6px_rgba(5,6,11,1),0_14px_40px_-10px_rgba(46,124,255,0.45)] transition-colors group-hover:border-electric-400/70">
                      <step.icon className="h-6 w-6 text-electric-400" aria-hidden />
                    </div>
                    <span
                      className="font-display text-4xl font-bold text-white/[0.09] transition-colors group-hover:text-electric-500/25"
                      aria-hidden
                    >
                      {step.number}
                    </span>
                  </div>
                  <h3 className="font-display text-lg font-semibold text-white">
                    <span className="sr-only">Step {step.number}: </span>
                    {step.title}
                  </h3>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                    {step.description}
                  </p>
                </li>
              </Reveal>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}
