"use client";

import { useState } from "react";
import {
  CheckCircle2,
  Clock,
  Loader2,
  Mail,
  MapPin,
  Phone,
  Send,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { SectionHeading } from "@/components/site/SectionHeading";
import { Reveal } from "@/components/site/Reveal";

const WEBSITE_TYPES = [
  "Business Website",
  "E-commerce Store",
  "Shopify Store",
  "Website Redesign",
  "Landing Page",
  "Not Sure Yet — Need Advice",
];

const CONTACT_DETAILS = [
  {
    icon: Mail,
    label: "Email",
    value: "brainboltoffical@gmail.com",
    href: "mailto:brainboltoffical@gmail.com",
  },
  {
    icon: Phone,
    label: "Phone / WhatsApp",
    value: "+91 74990 01739",
    href: "tel:+917499001739",
  },
  {
    icon: MapPin,
    label: "Location",
    value: "Pune, Maharashtra, India — working with clients worldwide",
    href: undefined,
  },
];

type FormState = {
  name: string;
  businessName: string;
  email: string;
  websiteType: string;
  description: string;
};

const INITIAL_FORM: FormState = {
  name: "",
  businessName: "",
  email: "",
  websiteType: "",
  description: "",
};

export function Contact() {
  const { toast } = useToast();
  const [form, setForm] = useState<FormState>(INITIAL_FORM);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  // Anti-spam: honeypot value (bots fill it) + render timestamp (time trap).
  const [honeypot, setHoneypot] = useState("");
  const [startedAt] = useState(() => Date.now());

  const setField = (key: keyof FormState, value: string) => {
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((e) => ({ ...e, [key]: undefined }));
  };

  const validate = (): boolean => {
    const next: Partial<Record<keyof FormState, string>> = {};
    if (form.name.trim().length < 2) next.name = "Please enter your name.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim()))
      next.email = "Please enter a valid email address.";
    if (!form.websiteType) next.websiteType = "Please choose a website type.";
    if (form.description.trim().length < 10)
      next.description = "Please describe your project in at least 10 characters.";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) {
      toast({
        title: "Almost there",
        description: "Please fix the highlighted fields and try again.",
        variant: "destructive",
      });
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/inquiry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, website_url: honeypot, startedAt }),
      });
      const data = await res.json();
      if (!res.ok || !data.ok) {
        throw new Error(data.error || "Failed to send your inquiry.");
      }
      setSubmitted(true);
      setForm(INITIAL_FORM);
      toast({
        title: "Inquiry sent successfully",
        description: "Thank you! We'll get back to you within 24–48 hours.",
      });
    } catch (err) {
      toast({
        title: "Something went wrong",
        description:
          err instanceof Error
            ? err.message
            : "Please try again or email us directly at brainboltoffical@gmail.com.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section id="contact" className="relative py-24 lg:py-32" aria-label="Contact">
      <div
        className="absolute left-[-180px] bottom-0 h-[420px] w-[420px] rounded-full bg-electric-600/[0.08] blur-[130px]"
        aria-hidden
      />
      <div className="relative mx-auto w-full max-w-7xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="Get In Touch"
          title={
            <>
              Start Your <span className="text-gradient-electric">Project</span> Today
            </>
          }
          subtitle="Tell us about your business and the website you need. We aim to reply to every inquiry within 24–48 hours."
        />

        <div className="mt-14 grid gap-8 lg:grid-cols-[0.9fr_1.1fr] lg:gap-12">
          {/* Contact information */}
          <Reveal>
            <div className="flex h-full flex-col gap-5">
              {CONTACT_DETAILS.map((detail) => {
                const Inner = (
                  <>
                    <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-electric-400 to-electric-600 shadow-[0_10px_30px_-10px_rgba(46,124,255,0.6)]">
                      <detail.icon className="h-5 w-5 text-white" aria-hidden />
                    </span>
                    <span className="min-w-0">
                      <span className="block text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">
                        {detail.label}
                      </span>
                      <span className="mt-1 block break-words text-[15px] font-medium text-white">
                        {detail.value}
                      </span>
                    </span>
                  </>
                );
                return detail.href ? (
                  <a
                    key={detail.label}
                    href={detail.href}
                    className="card-border-glow flex items-center gap-4 rounded-2xl border border-white/[0.07] bg-card/70 p-5 transition-colors hover:border-electric-500/30 hover:bg-panel focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    {Inner}
                  </a>
                ) : (
                  <div
                    key={detail.label}
                    className="card-border-glow flex items-center gap-4 rounded-2xl border border-white/[0.07] bg-card/70 p-5"
                  >
                    {Inner}
                  </div>
                );
              })}

              <div className="flex-1 rounded-2xl border border-white/[0.07] bg-card/70 p-6 sm:p-7">
                <div className="flex items-center gap-2.5">
                  <Clock className="h-4 w-4 text-electric-400" aria-hidden />
                  <p className="text-sm font-semibold text-white">Currently accepting new projects</p>
                </div>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                  Whether you need your first business website or a complete online store, send over
                  the details and you will receive a clear, honest response — including realistic
                  timelines and next steps. No pressure, no obligations.
                </p>
                <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
                  Prefer email? Write to us directly at{" "}
                  <a
                    href="mailto:brainboltoffical@gmail.com"
                    className="font-medium text-electric-400 underline-offset-4 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded"
                  >
                    brainboltoffical@gmail.com
                  </a>{" "}
                  — we read every message.
                </p>
              </div>
            </div>
          </Reveal>

          {/* Inquiry form */}
          <Reveal delay={0.12}>
            <div className="card-border-glow rounded-3xl border border-white/[0.07] bg-card/70 p-7 sm:p-9">
              {submitted ? (
                <div className="flex min-h-[420px] flex-col items-center justify-center text-center" role="status">
                  <span className="flex h-16 w-16 items-center justify-center rounded-full bg-electric-500/15 border border-electric-500/30">
                    <CheckCircle2 className="h-8 w-8 text-electric-400" aria-hidden />
                  </span>
                  <h3 className="mt-6 font-display text-2xl font-bold text-white">
                    Thank you — your inquiry has been received!
                  </h3>
                  <p className="mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                    We appreciate you reaching out. You will receive a response at your email
                    address within 24–48 hours. For anything urgent, feel free to call
                    +91 74990 01739.
                  </p>
                  <Button
                    onClick={() => setSubmitted(false)}
                    variant="outline"
                    className="mt-8 rounded-full border-white/15 bg-white/[0.03] font-semibold text-white hover:border-electric-500/60 hover:bg-electric-500/10 hover:text-white"
                  >
                    Send Another Inquiry
                  </Button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} noValidate>
                  {/* Honeypot — visually hidden; real users never see or fill this */}
                  <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
                    <label htmlFor="website_url">Website URL</label>
                    <input
                      id="website_url"
                      name="website_url"
                      type="text"
                      tabIndex={-1}
                      autoComplete="off"
                      value={honeypot}
                      onChange={(e) => setHoneypot(e.target.value)}
                    />
                  </div>
                  <div className="grid gap-5 sm:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="name" className="text-sm text-foreground">
                        Name <span className="text-electric-400">*</span>
                      </Label>
                      <Input
                        id="name"
                        name="name"
                        placeholder="Your full name"
                        value={form.name}
                        onChange={(e) => setField("name", e.target.value)}
                        aria-invalid={!!errors.name}
                        className="h-11 border-white/10 bg-white/[0.04] text-white placeholder:text-muted-foreground/60 focus-visible:border-electric-500/60"
                      />
                      {errors.name && <p className="text-xs text-red-400">{errors.name}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="businessName" className="text-sm text-foreground">
                        Business Name
                      </Label>
                      <Input
                        id="businessName"
                        name="businessName"
                        placeholder="Your business or brand"
                        value={form.businessName}
                        onChange={(e) => setField("businessName", e.target.value)}
                        className="h-11 border-white/10 bg-white/[0.04] text-white placeholder:text-muted-foreground/60 focus-visible:border-electric-500/60"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-sm text-foreground">
                        Email <span className="text-electric-400">*</span>
                      </Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        inputMode="email"
                        placeholder="you@example.com"
                        value={form.email}
                        onChange={(e) => setField("email", e.target.value)}
                        aria-invalid={!!errors.email}
                        className="h-11 border-white/10 bg-white/[0.04] text-white placeholder:text-muted-foreground/60 focus-visible:border-electric-500/60"
                      />
                      {errors.email && <p className="text-xs text-red-400">{errors.email}</p>}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="websiteType" className="text-sm text-foreground">
                        Type of Website <span className="text-electric-400">*</span>
                      </Label>
                      <Select
                        value={form.websiteType}
                        onValueChange={(v) => setField("websiteType", v)}
                      >
                        <SelectTrigger
                          id="websiteType"
                          aria-invalid={!!errors.websiteType}
                          className="!h-11 w-full border-white/10 bg-white/[0.04] text-white data-[placeholder]:text-muted-foreground/60 focus-visible:border-electric-500/60"
                        >
                          <SelectValue placeholder="Select a website type" />
                        </SelectTrigger>
                        <SelectContent className="border-white/10 bg-[#0d1019] text-white">
                          {WEBSITE_TYPES.map((type) => (
                            <SelectItem key={type} value={type} className="focus:bg-electric-500/20 focus:text-white">
                              {type}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {errors.websiteType && (
                        <p className="text-xs text-red-400">{errors.websiteType}</p>
                      )}
                    </div>
                    <div className="space-y-2 sm:col-span-2">
                      <Label htmlFor="description" className="text-sm text-foreground">
                        Project Description <span className="text-electric-400">*</span>
                      </Label>
                      <Textarea
                        id="description"
                        name="description"
                        rows={5}
                        placeholder="Tell us about your business, what you need and any ideas you have — e.g. pages, features, examples you like."
                        value={form.description}
                        onChange={(e) => setField("description", e.target.value)}
                        aria-invalid={!!errors.description}
                        className="min-h-[130px] resize-y border-white/10 bg-white/[0.04] text-white placeholder:text-muted-foreground/60 focus-visible:border-electric-500/60"
                      />
                      {errors.description && (
                        <p className="text-xs text-red-400">{errors.description}</p>
                      )}
                    </div>
                  </div>

                  <Button
                    type="submit"
                    disabled={submitting}
                    className="glow-electric mt-7 h-12 w-full rounded-full bg-electric-500 text-[15px] font-semibold text-white hover:bg-electric-600 disabled:opacity-60 sm:w-auto sm:px-10"
                  >
                    {submitting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden />
                        Sending Your Inquiry…
                      </>
                    ) : (
                      <>
                        <Send className="mr-2 h-4 w-4" aria-hidden />
                        Contact Us — Send Project Inquiry
                      </>
                    )}
                  </Button>
                  <p className="mt-4 text-xs leading-relaxed text-muted-foreground">
                    By submitting this form you agree to be contacted about your project inquiry. Your
                    details are stored securely, never shared with third parties, and this site uses
                    privacy-first, cookieless analytics.
                  </p>
                </form>
              )}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
