"use client";

import Image from "next/image";
import { ArrowUpRight, Info } from "lucide-react";
import { motion } from "framer-motion";
import { SectionHeading } from "@/components/site/SectionHeading";
import { Reveal } from "@/components/site/Reveal";

type Project = {
  name: string;
  category: string;
  badge: "Demo Project" | "Concept Project";
  image: string;
  imageAlt: string;
  summary: string;
  highlights: string[];
  tags: string[];
};

const PROJECTS: Project[] = [
  {
    name: "Lumière — Fashion E-commerce Store",
    category: "Fashion · Online Store",
    badge: "Demo Project",
    image: "/work/fashion-store-v2.png",
    imageAlt:
      "Preview of the Lumière fashion e-commerce demo website with an editorial hero and clean product grid",
    summary:
      "A premium fashion storefront with an editorial homepage, curated collections and a clean product grid — designed to make online shopping feel effortless and elegant.",
    highlights: [
      "Editorial homepage with seasonal collection showcase",
      "Structured product grid with category filtering layout",
      "Smooth, distraction-free path from browsing to checkout",
    ],
    tags: ["E-commerce", "Editorial Design", "Responsive"],
  },
  {
    name: "Saffron & Smoke — Modern Restaurant",
    category: "Restaurant · Hospitality",
    badge: "Demo Project",
    image: "/work/restaurant.png",
    imageAlt:
      "Preview of the Saffron and Smoke restaurant demo website with a moody hero and menu showcase",
    summary:
      "A moody, appetising website for a modern restaurant — showcasing the menu, atmosphere and reservations so guests can decide (and book) within minutes of landing.",
    highlights: [
      "Atmosphere-first hero with signature dishes on display",
      "Clear menu sections designed for easy scanning",
      "Reservation-ready layout with prominent contact actions",
    ],
    tags: ["Restaurant", "Menu Design", "Reservations"],
  },
  {
    name: "Aura Beauty Studio — Beauty Salon",
    category: "Beauty Salon · Wellness",
    badge: "Concept Project",
    image: "/work/beauty-salon.png",
    imageAlt:
      "Preview of the Aura Beauty Studio salon concept website with a soft hero and booking section",
    summary:
      "A soft, luxurious concept for a beauty salon — presenting services and pricing clearly and guiding visitors towards booking an appointment in just a few taps.",
    highlights: [
      "Service menu with clear pricing presentation",
      "Booking-focused layout with persistent call-to-action",
      "Calm, premium visual identity across every section",
    ],
    tags: ["Salon", "Booking Flow", "Service Showcase"],
  },
];

export function Portfolio() {
  return (
    <section id="work" className="relative py-24 lg:py-32" aria-label="Our work">
      <div
        className="absolute right-[-220px] top-24 h-[460px] w-[460px] rounded-full bg-electric-600/[0.07] blur-[130px]"
        aria-hidden
      />
      <div className="relative mx-auto w-full max-w-7xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="Our Work"
          title={
            <>
              Demo Projects, <span className="text-gradient-electric">Real Craftsmanship</span>
            </>
          }
          subtitle="A look at how we design for real business scenarios — every layout planned around customers, content and conversions."
        />

        {/* Transparency notice */}
        <Reveal className="mx-auto mt-8 max-w-3xl" delay={0.15}>
          <div className="flex items-start gap-3.5 rounded-xl border border-electric-500/25 bg-electric-500/[0.07] px-5 py-4">
            <Info className="mt-0.5 h-5 w-5 shrink-0 text-electric-400" aria-hidden />
            <p className="text-sm leading-relaxed text-foreground/80">
              <span className="font-semibold text-white">Transparency note: </span>
              the projects below are demo and concept builds we created to demonstrate our design
              style and process. They are clearly labelled as such and are not client work. Real
              client projects will be showcased here as they are completed.
            </p>
          </div>
        </Reveal>

        <div className="mt-14 flex flex-col gap-10 lg:gap-16">
          {PROJECTS.map((project, i) => {
            const reversed = i % 2 === 1;
            return (
              <Reveal key={project.name} delay={0.05}>
                <motion.article
                  whileHover={{ y: -4 }}
                  transition={{ type: "spring", stiffness: 240, damping: 22 }}
                  className={`card-border-glow group grid overflow-hidden rounded-3xl border border-white/[0.07] bg-card/70 lg:grid-cols-2 ${
                    reversed ? "" : ""
                  }`}
                >
                  {/* Browser-framed preview */}
                  <div
                    className={`relative border-b border-white/[0.07] p-5 pb-0 sm:p-7 sm:pb-0 lg:border-b-0 ${
                      reversed ? "lg:order-2" : ""
                    }`}
                  >
                    <div className="relative h-full overflow-hidden rounded-t-xl border border-white/10 bg-[#0b0e16]">
                      <div className="flex items-center gap-2 border-b border-white/[0.07] bg-white/[0.03] px-4 py-2.5">
                        <div className="flex gap-1.5">
                          <span className="h-2 w-2 rounded-full bg-[#ff5f57]" />
                          <span className="h-2 w-2 rounded-full bg-[#febc2e]" />
                          <span className="h-2 w-2 rounded-full bg-[#28c840]" />
                        </div>
                        <div className="flex-1 truncate rounded bg-black/40 px-2.5 py-1 text-[10px] text-muted-foreground">
                          {project.name.split("—")[0].trim().toLowerCase().replace(/[^a-z0-9]+/g, "") || "demo"}.com
                        </div>
                      </div>
                      <div className="relative aspect-[16/9.4] overflow-hidden">
                        <Image
                          src={project.image}
                          alt={project.imageAlt}
                          fill
                          sizes="(max-width: 1024px) 100vw, 50vw"
                          className="object-cover object-top transition-transform duration-700 group-hover:scale-[1.04]"
                        />
                      </div>
                    </div>
                    <span
                      className={`absolute left-7 top-[4.6rem] z-10 inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-[10.5px] font-bold uppercase tracking-[0.14em] sm:top-[4.9rem] ${
                        project.badge === "Demo Project"
                          ? "bg-electric-500 text-white shadow-[0_6px_20px_-4px_rgba(46,124,255,0.7)]"
                          : "bg-white text-[#05060B] shadow-[0_6px_20px_-6px_rgba(255,255,255,0.4)]"
                      }`}
                    >
                      {project.badge}
                    </span>
                  </div>

                  {/* Details */}
                  <div className={`flex flex-col justify-center p-7 lg:p-12 ${reversed ? "lg:order-1" : ""}`}>
                    <p className="text-[11.5px] font-semibold uppercase tracking-[0.24em] text-electric-400">
                      {project.category}
                    </p>
                    <h3 className="mt-3 font-display text-2xl font-bold text-white lg:text-[1.7rem]">
                      {project.name}
                    </h3>
                    <p className="mt-4 text-[15px] leading-relaxed text-muted-foreground">
                      {project.summary}
                    </p>
                    <ul className="mt-6 space-y-2.5">
                      {project.highlights.map((h) => (
                        <li key={h} className="flex items-start gap-2.5 text-sm text-foreground/85">
                          <span className="mt-[7px] h-1.5 w-1.5 shrink-0 rounded-full bg-electric-400" aria-hidden />
                          {h}
                        </li>
                      ))}
                    </ul>
                    <div className="mt-7 flex flex-wrap items-center gap-2">
                      {project.tags.map((tag) => (
                        <span
                          key={tag}
                          className="rounded-full border border-white/[0.08] bg-white/[0.03] px-3 py-1 text-[11.5px] font-medium tracking-wide text-foreground/70"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                    <a
                      href="#contact"
                      className="mt-8 inline-flex w-fit items-center gap-1.5 text-sm font-semibold text-electric-400 transition-colors hover:text-electric-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded"
                    >
                      Want a website like this?
                      <ArrowUpRight className="h-4 w-4" aria-hidden />
                    </a>
                  </div>
                </motion.article>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
