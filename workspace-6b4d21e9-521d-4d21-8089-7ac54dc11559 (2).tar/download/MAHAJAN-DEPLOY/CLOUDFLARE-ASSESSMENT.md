# Cloudflare Deployment Assessment — mahajanwebstudio.pages.dev

**Date:** 2 November 2026 · **Method:** real build + runtime tests on a throwaway copy in `/tmp` — your live website was NOT touched.

---

## The verdict (honest, tested today)

| Target | Full website (form + admin + analytics)? | Verdict |
|---|---|---|
| `mahajanwebstudio.pages.dev` — **Pages** | ❌ **Not possible, free or paid** | Cloudflare **deprecated** the Next.js-on-Pages adapter (`@cloudflare/next-on-pages`). It only supported the Edge runtime — no Node APIs, no Prisma, no native crypto. Pages is now recommended by Cloudflare **only for static exports**, and a static export cannot run your contact form, admin panel or analytics (they are server features). Splitting the site into "static front + separate backend" would break the "keep everything unchanged" requirement. |
| `mahajanwebstudio.<yourname>.workers.dev` — **Workers (OpenNext)** | ✅ Possible **after a database port** | Build tested today with the real project: **PASSED** (whole Next 16 app bundled into a Cloudflare Worker). Pages render fine. The database layer fails at runtime → needs the D1 port described below. 100% free, no card. |
| `mahajanwebstudio.vercel.app` — **Vercel** (package already ready) | ✅ Ready today, least work | Name verified unclaimed. Only the DB swap (Neon free) is needed. ~30 min. |

**Bottom line:** the exact name `pages.dev` cannot host this website with all features working. The closest Cloudflare experience is **Workers** (`…workers.dev`, free). If the name `mahajanwebstudio.<something>` matters most, Vercel gives you `mahajanwebstudio.vercel.app` with far less work.

---

## Test evidence (2 November 2026)

Ran on a throwaway copy of the project (live site untouched):

1. `bun install` + `@opennextjs/cloudflare` + `wrangler` → OK
2. `opennextjs-cloudflare build` → **complete success** — `Worker saved in .open-next/worker.js`
3. `wrangler dev` (real Cloudflare workerd runtime, local):
   - `GET /` → **200**, correct MAHAJAN title — SSR works ✅
   - `GET /admin/login` → **200** — page renders ✅
   - `POST /api/admin/login` → **500** "Login is temporarily unavailable" — **database fails** ❌
   - `POST /api/track` → 204 (its error-catcher hides DB failure — confirmed in code) ❌

**Root cause:** Prisma uses a native SQLite engine binary. Cloudflare's workerd runtime cannot load native binaries. The database must move to **Cloudflare D1** (Cloudflare's own serverless SQLite — free tier) through Prisma's D1 driver adapter.

---

## Migration requirements (what would change — nothing done yet)

| # | Item | Change needed | Impact on you |
|---|---|---|---|
| 1 | **Database** | SQLite file → **Cloudflare D1** (free: 5 GB storage, millions of row-reads/day). Code: swap Prisma datasource to the D1 adapter (`@prisma/adapter-d1`), update `src/lib/db.ts`, add D1 binding in `wrangler.jsonc`. Models stay identical. | None visible — same admin, same analytics |
| 2 | **Data transfer** | One-time export from the current SQLite file into D1. Current data is tiny (8 page views, 0 enquiries, 1 admin). I script it. | ~2 minutes, automated |
| 3 | **Password hashing** | `scrypt` support inside workerd must be verified at implementation time. If unsupported, switch to `pbkdf2` (built into workerd). This means re-seeding the admin password once (you type a new password — 2 minutes). | One-time password re-entry |
| 4 | **Config & build** | New files `open-next.config.ts`, `wrangler.jsonc`; build command becomes `opennextjs-cloudflare build && opennextjs-cloudflare deploy`. | None — I prepare all files |
| 5 | **Everything else** | Design, content, services, portfolio, contact form, admin panel, analytics, security features — **zero changes** | Nothing |

**Total: ~45–60 minutes of porting work (mine) + ~10 minutes of account steps (yours). Cost: Rs. 0 forever.**

---

## Exact steps — Path A: Cloudflare Workers (after your approval)

**I do (in a copy, then hand you the ready folder):**
1. Port Prisma to the D1 adapter + update `db.ts` + add `wrangler.jsonc` binding
2. Verify/adjust password hashing for workerd
3. Build + test every route locally in the Cloudflare runtime (home, form, admin login, analytics)
4. Script the data export (SQLite → D1)

**You do (~10 min, all free):**
1. Create a free account at **dash.cloudflare.com** (email only, no card)
2. Install Node.js (free) on your computer, then: `npm install -g wrangler`
3. `wrangler login` → browser opens → approve
4. From the project folder:
   - `wrangler d1 create mahajan-db` → paste the returned ID into `wrangler.jsonc` (I mark the spot)
   - `wrangler d1 execute mahajan-db --file=./prisma/d1-schema.sql` (creates tables)
   - `wrangler d1 execute mahajan-db --file=./data-export.sql` (imports your data)
   - `wrangler deploy` — Worker name: `mahajanwebstudio`
5. Enable the workers.dev subdomain in the dashboard → your site is live at
   **`https://mahajanwebstudio.<your-subdomain>.workers.dev`** — free SSL, automatic, no warnings
6. Seed the admin (one command from the guide), sign in via the footer "MS" link, done

## Exact steps — Path B: Vercel (ready today, least work)

Already written step-by-step with copy-paste commands in **`MAHAJAN-DEPLOY/DEPLOY-GUIDE.md`** (Neon free database + GitHub + Vercel import). Name: `mahajanwebstudio.vercel.app`. ~30 minutes.

---

## Free-tier facts (Cloudflare docs, verified September 2026)

- Workers free: **100,000 requests/day** — a portfolio site uses a tiny fraction
- D1 free: 5 GB storage + millions of row-reads/day — your analytics will never come close
- No credit card anywhere; nothing expires into a paid plan

## Safety statement

Nothing on your current website, database, admin panel or analytics was modified, moved or deleted for this assessment. The Cloudflare test ran entirely on a disposable copy in `/tmp`. Backups remain in `db/backups/`.
