/**
 * MAHAJAN — secure server-side admin password (re)configuration.
 *
 * Purpose: set or reset the single authorized administrator's password
 * WITHOUT ever hardcoding or logging the plaintext secret.
 *
 * Usage (from the project root, password supplied via environment only):
 *   ADMIN_USERNAME="Jaguu" ADMIN_EMAIL="brainboltoffical@gmail.com" \
 *   ADMIN_PASSWORD="<strong password>" bun scripts/reset-admin-password.ts
 *
 * Security notes:
 * - The plaintext password is read from the process environment at run time
 *   and is never written to any file, database column, or log line.
 * - Only a scrypt hash (salt + derived key, format `s1$salt$hash`) is stored.
 * - All previously active sessions are revoked so old cookies stop working.
 * - The username/email are never printed; only row counts are reported.
 */
import { PrismaClient } from "@prisma/client";
import { randomBytes, scryptSync } from "node:crypto";

const prisma = new PrismaClient();

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `s1$${salt}$${hash}`;
}

async function main() {
  const username = process.env.ADMIN_USERNAME || "Jaguu";
  const email = process.env.ADMIN_EMAIL || "brainboltoffical@gmail.com";
  const password = process.env.ADMIN_PASSWORD;

  if (!password || password.length < 12) {
    console.error("ADMIN_PASSWORD env var is required (min 12 characters). Nothing was changed.");
    process.exit(1);
  }

  const existing = await prisma.adminUser.findFirst();

  if (existing) {
    await prisma.adminUser.update({
      where: { id: existing.id },
      data: { passwordHash: hashPassword(password) },
    });
    // Revoke every active session: old cookies must not survive a reset.
    const revoked = await prisma.session.updateMany({
      where: { adminId: existing.id, revokedAt: null },
      data: { revokedAt: new Date() },
    });
    console.log(
      `Admin password updated (username unchanged, count=${existing.username.length} chars). Sessions revoked: ${revoked.count}.`
    );
    return;
  }

  await prisma.adminUser.create({
    data: {
      username,
      email,
      passwordHash: hashPassword(password),
    },
  });
  console.log("Admin account created. Password stored as scrypt hash only.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
