#!/usr/bin/env bash
# Ensures the MAHAJAN dev server is up on :3000 and ready to serve.
# Usage: bash scripts/dev-ensure.sh
cd /home/z/my-project

if ss -tlnp 2>/dev/null | grep -q ':3000'; then
  if curl -sf -o /dev/null -m 5 http://localhost:3000/; then
    echo "SERVER: already up"
    exit 0
  fi
  # stale listener that does not respond — kill it
  pkill -f "next dev" 2>/dev/null
  pkill -f "next-server" 2>/dev/null
  sleep 2
fi

setsid bash -c 'cd /home/z/my-project && bun run dev' >/dev/null 2>&1 < /dev/null &
disown

for i in $(seq 1 40); do
  sleep 1
  if curl -sf -o /dev/null -m 3 http://localhost:3000/; then
    echo "SERVER: started (waited ${i}s)"
    exit 0
  fi
done

echo "SERVER: FAILED to start"
tail -20 dev.log 2>/dev/null
exit 1
