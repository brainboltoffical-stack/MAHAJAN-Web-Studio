/**
 * Seeds the single authorized MAHAJAN administrator.
 *
 * Usage (one-time, from the project root):
 *   ADMIN_USERNAME="Jaguu" ADMIN_EMAIL="brainboltoffical@gmail.com" \
 *   ADMIN_PASSWORD="<strong password>" bun scripts/seed-admin.ts
 *
 * The plaintext password is ONLY read from the environment at seed time.
 * What gets stored in the database is a scrypt hash (salt + derived key).
 * The password is never written to any source file, config or log.
 */
import { PrismaClient } from "@prisma/client";
import { randomBytes, scryptSync } from "node:crypto";

const prisma = new PrismaClient();

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `s1$${salt}$${hash}`;
}

async function main() {
  const username = process.env.ADMIN_USERNAME || "Jaguu";
  const email = process.env.ADMIN_EMAIL || "brainboltoffical@gmail.com";
  const password = process.env.ADMIN_PASSWORD;

  if (!password || password.length < 12) {
    console.error("ADMIN_PASSWORD env var is required (min 12 characters). Nothing was written.");
    process.exit(1);
  }

  const existing = await prisma.adminUser.findFirst();

  if (existing) {
    console.log(`An admin account already exists (username: ${existing.username}). Skipping seed.`);
    console.log("Re-seed only after clearing the AdminUser table, or change the password from Settings.");
    return;
  }

  await prisma.adminUser.create({
    data: {
      username,
      email,
      passwordHash: hashPassword(password),
    },
  });

  console.log(`Admin account created for username "${username}". Password stored as scrypt hash only.`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
